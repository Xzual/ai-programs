import{a as e}from"./chunk-BNv3lrIs.js";import{t}from"./react-BFwN_vxz.js";import{t as n}from"./jsx-runtime-kJazARoa.js";import{Bo as r,Bs as i,Vs as a,do as o,ei as s,ra as c,va as l}from"./three.module-IFVRcQ3V.js";import{l as u,s as d}from"./constants-Dg99kINN.js";var f=e(t(),1),p=n(),m=new a(Math.SQRT1_2,0,Math.SQRT1_2);new a(Math.SQRT1_2,0,-Math.SQRT1_2);var h=new a(0,1,0),g=new l,_=new l,v=typeof window<`u`&&window.innerWidth<768,y=v?25e3:5e4,b=1.95,x=.035,S=v?7e3:14e3,C=2.65,w=.075,T=-1.62;function E(e,t){let n=Math.sin(e*127.1+t*311.7)*43758.5453;return n-Math.floor(n)}function D(e,t){let n=Math.floor(e),r=Math.floor(t),i=e-n,a=t-r,o=i*i*(3-2*i),s=a*a*(3-2*a),c=E(n,r),l=E(n+1,r),u=E(n,r+1),d=E(n+1,r+1);return c+(l-c)*o+(u-c)*s+(c-l-u+d)*o*s}function O(e,t){let n=.5,r=1,i=0,a=1;for(let o=0;o<5;o+=1){let o=D(e*r,t*r);o=1-Math.abs(2*o-1),o*=o,i+=o*n*a,a=Math.min(1,o*2),n*=.5,r*=2.13}return i}var k=(e,t,n)=>{let r=Math.max(0,Math.min(1,(n-e)/(t-e)));return r*r*(3-2*r)};function A(e,t){return O(e*.42+7.3,t*.42-2.9)**1.3*4.4}function j(e,t){let n=new Float32Array(e*3),r=new Float32Array(e*3);for(let i=0;i<e;i+=1){let e=i*3,a=Math.random(),o=0,s=0,c=0,l=0,u=0,d=0;if(!t&&a<.42){o=(Math.random()*2-1)*10,c=1.5-Math.random()*9,s=T+Math.random()*.03;let e=Math.max(Math.abs(o),-c*.6),t=(.13+Math.random()*.08)*(1-k(4,10,e)*.8);l=t*1.12,u=t*.99,d=t*.8}else if(a<(t?.6:.93)){let e=0;for(let t=0;t<18&&(o=(Math.random()*2-1)*9,c=-4.5-Math.random()*6.5,e=A(o,c),!(e>.35));t+=1);let n=Math.random(),r=t?.74+.26*n:n**.36;s=T+e*r;let i=Math.min(1,(s-T)/3.6),a=Math.min(1,(-c-4.5)/6.5),f=(.12+.62*i**1.2+Math.random()*.05)*(t?1.3:1),p=a*.42;l=f*(.66+i*.02)*(1-p)+.1*p,u=f*(.6+i*.14)*(1-p)+.13*p,d=f*(.5+i*.42)*(1-p)+.2*p}else{o=(Math.random()*2-1)*20,s=2.2+Math.random()**1.4*8,c=-9-Math.random()*14;let e=(.06+Math.random()*.12)*(Math.random()<.06?2.2:1)*(t?1.3:1);l=e*.85,u=e*.95,d=e*1.08}n[e]=o,n[e+1]=s,n[e+2]=c,r[e]=l,r[e+1]=u,r[e+2]=d}return{terra:n,terraCol:r}}var M=`
  attribute vec3 seed;
  attribute vec3 aStartPos;
  uniform float uTime;
  uniform vec3 uMouse;
  uniform float uMouseInfluence;
  uniform float uPixelRatio;
  uniform vec2 uTilt;
  uniform float uIntroT;       /* 0 → 1 across the intro rush-in.
                                  At 0 particle is at aStartPos
                                  (behind camera), at 1 it's in
                                  its resting sphere position. */
  uniform float uHeat;         /* 0 = brand aurora palette, 1 =
                                  fiery sun palette (yellow / orange /
                                  red).  Used to transform the same
                                  globe into a heat ball when it
                                  re-appears behind the Manifesto. */
  uniform float uExtraRotation;/* scroll-driven Y rotation added on top
                                  of the slow ambient spin. */
  uniform float uTint;         /* 0 = ember red, 1 = violet ember.
                                  Shifts hue once the reader scrolls
                                  past the manifesto. */
  uniform float uOpacity;      /* 1 = fully visible, 0 = invisible.
                                  Lets the sphere fade independently
                                  of the ring so the brand mark can
                                  break apart on cue. */
  uniform float uExplode;      /* 0 = at rest, 1 = fully exploded.
                                  Drives the "tap-to-burst" effect
                                  on the Contact section — particles
                                  fly outward and fade. */
  uniform float uTerra;        /* 0 = sphere, 1 = the HALO desert.
                                  Scroll-driven on the #halo section:
                                  the sphere BREAKS APART and its
                                  particles stream into the landscape
                                  (floor / mountains / stars), each
                                  particle peeling off on its own
                                  seed-staggered cue. */
  attribute vec3 aTerra;       /* this particle's landscape position */
  attribute vec3 aTerraCol;    /* and its landscape colour */
  varying vec3 vColor;
  varying float vAlpha;

  /* Helpers to rotate a 3D point around the X / Y world axes. */
  vec3 rotateY(vec3 p, float a) {
    float c = cos(a), s = sin(a);
    return vec3(c * p.x + s * p.z, p.y, -s * p.x + c * p.z);
  }
  vec3 rotateX(vec3 p, float a) {
    float c = cos(a), s = sin(a);
    return vec3(p.x, c * p.y - s * p.z, s * p.y + c * p.z);
  }

  /* Aurora-borealis swirl palette — wider tonal range now so
     the colour flow reads as paint rushing rather than a gentle
     pastel mix: deep navy through bright cyan / aurora-green,
     with a near-white cyan at the highlights. */
  const vec3 AURORA_BLUE  = vec3(0.04, 0.18, 0.78);  /* deep navy-blue */
  const vec3 AURORA_CYAN  = vec3(0.72, 1.00, 1.00);  /* near-white cyan highlight */
  const vec3 AURORA_GREEN = vec3(0.22, 0.95, 0.50);  /* punchy aurora green */

  void main() {
    /* === INTRO RUSH-IN =================================
       For the first ~2.5 s of the user's first visit, blend
       from a position behind / above the camera (aStartPos) to
       the particle's resting sphere position. Cubic-out so they
       arrive feeling like they're decelerating into formation. */
    float introEase = 1.0 - pow(1.0 - clamp(uIntroT, 0.0, 1.0), 3.0);
    vec3 pos = mix(aStartPos, position, introEase);

    /* === MOBILE TILT PARALLAX ===
       uTilt is non-zero only on touch devices. Tilting the phone
       rotates the entire sphere through small angles (max ~12°),
       so the brand mark feels like a physical object reacting to
       the phone's orientation in space. */
    pos = rotateY(pos, uTilt.x * 0.22);
    pos = rotateX(pos, uTilt.y * 0.22);

    /* Slow rigid rotation of the entire shell around y, plus the
       scroll-driven extra rotation so the globe visibly spins on
       its axis as the reader scrolls into the manifesto. */
    float ang = uTime * 0.06 + uExtraRotation;
    float c = cos(ang), s = sin(ang);
    vec3 rotated = vec3(c * pos.x + s * pos.z, pos.y, -s * pos.x + c * pos.z);
    pos = rotated;
    /* Per-particle wobble — tiny radial breathe. */
    pos += normalize(pos) * sin(uTime * 0.7 + seed.x * 6.28) * 0.012;

    /* Prominence-arm code removed — sphere just glows hot
       (heat-mode palette) without any erupting flares. */

    /* Mouse interaction — IMPLODE + ENGULF (replaces repel).

         Particles inside REACH are pulled TOWARD the cursor, but
         only down to ENGULF — at that radius they hold and form a
         glowing shell wrapped around the cursor.

           d > ENGULF : pull inward  (the implosion)
           d < ENGULF : push outward (so particles don't pile into
                        the cursor; they sit on the shell)
           d = ENGULF : equilibrium

         uMouseInfluence still fades the whole effect smoothly
         across the sphere silhouette so entering/leaving has no
         snap. */
    /* Default: no crater glow / dimming. Updated below when the
       particle is inside the impact zone. */
    float shellGlow = 0.0;

    /* === ASTEROID IMPACT / CRATER (smooth field) ===
         Cursor acts like a meteor hitting the sphere surface.
         Instead of piecewise depression + bulge with hard edges,
         this uses a single SMOOTH FIELD that goes:
           depression at the centre, through 0, to a small bulge
           ring, back to 0 in the far field. Continuous, no seams.

         Two gaussian terms shape the field:
           dent  peaks at d=0  (the impact centre, deep depression)
           bulge peaks near SIGMA (the crater rim, gentle lift)
           both decay smoothly to zero. */
    vec3 toCursor = uMouse - pos;
    float d = length(toCursor);
    float SIGMA = 0.55;
    float r2 = (d * d) / (SIGMA * SIGMA);

    /* Skip particles way past the influence — pure perf optimisation. */
    if (r2 < 16.0 && d > 0.001) {
      vec3 outward = normalize(pos);

      /* Shallower + wider dent profile: the lower exp coefficient
         spreads the depression over more area while the lower
         DENT_AMP makes it less deep. Result feels like a hand
         pressed into the surface, not a spike puncturing it. */
      float dent  = exp(-r2 * 2.5);
      float bulge = r2 * exp(-r2 * 1.4);

      float DENT_AMP  = 0.32;
      float BULGE_AMP = 0.95;
      float disp = -dent * DENT_AMP + bulge * BULGE_AMP;

      pos += outward * disp * uMouseInfluence;

      /* shellGlow: bulge particles get a stronger positive value
         so they read as a brighter ejecta ring; depression is
         lighter so it doesn't read as a void. */
      shellGlow = (bulge * 2.0 - dent * 0.45) * uMouseInfluence;
    }

    /* === SWIRLING AURORA FIELD ===
         Faster motion now — particles flow visibly through the
         color spectrum as the noise field drifts. */
    float n1 = sin(pos.x * 1.4 + pos.y * 0.7 + uTime * 0.95) * 0.5 + 0.5;
    float n2 = sin(pos.y * 1.1 - pos.z * 1.3 + uTime * 0.78 + 1.7) * 0.5 + 0.5;
    float swirl = (n1 + n2) * 0.5;
    swirl += (seed.x - 0.5) * 0.18;
    swirl = clamp(swirl, 0.0, 1.0);

    vec3 col = mix(AURORA_BLUE, AURORA_GREEN, swirl);
    float cyanBoost = 1.0 - abs(swirl - 0.5) * 2.0;
    col = mix(col, AURORA_CYAN, cyanBoost * 0.45);

    /* Curtain wave — bigger contrast between dim and bright
       bands so colours rush across the sphere like waves of paint. */
    float curtain = sin(pos.y * 0.9 + uTime * 0.6 + seed.y * 6.28) * 0.5 + 0.5;
    col *= 0.45 + curtain * 0.95;

    /* Crater glow: bulge particles brighten toward near-white
       cyan and pop visually so the ejecta ring is unmistakable;
       depression particles dim. */
    col = mix(col, vec3(0.85, 1.00, 1.00), max(shellGlow, 0.0) * 0.80);
    col = mix(col, vec3(0.04, 0.10, 0.15), max(-shellGlow, 0.0) * 0.55);

    /* === HEAT MODE ====================================
       Settled state is a dark-red ember tone (EMBER_DEEP →
       EMBER_BRIGHT mixed by the swirl noise). The TRANSITION
       between cyan and that final ember red is what makes the
       handoff feel cool, not the endpoints: as uHeat ramps 0→1,
       each particle crosses through a bright-orange ignition
       flash at its OWN per-particle threshold. Some particles
       still glow cyan past 50% heat while others have already
       gone hot — the sphere reads as boiling into red, not
       cross-fading uniformly. */
    /* Red / orange / violet bumped brighter (user request — they
       read too dim on mobile).  Green + cyan kept as-is so the
       MeetVega / Compare beats don't get blown out. */
    vec3 EMBER_DEEP   = vec3(0.32, 0.04, 0.02);
    vec3 EMBER_BRIGHT = vec3(1.00, 0.22, 0.10);
    vec3 IGNITION     = vec3(1.00, 0.55, 0.10);  /* bright orange flash */
    /* Five-stop colour ramp driven by uTint, mixed in order so
       the shift reads as a continuous gradient through every
       section:
         uTint 0 → 1 : ember red (Manifesto)  → orange (Mismatch)
         uTint 1 → 2 : orange    (Mismatch)   → green  (MeetVega)
         uTint 2 → 3 : green     (MeetVega)   → violet (AnyFacility)
         uTint 3 → 4 : violet    (AnyFacility)→ cyan   (Compare)
       The cyan stop closes the loop back to the hero's opening
       palette — a "return home" beat at the math section. */
    vec3 ORANGE_DEEP   = vec3(0.55, 0.18, 0.02);
    vec3 ORANGE_BRIGHT = vec3(1.00, 0.65, 0.18);
    vec3 GREEN_DEEP    = vec3(0.02, 0.20, 0.05);
    vec3 GREEN_BRIGHT  = vec3(0.18, 0.95, 0.45);
    vec3 VIOLET_DEEP   = vec3(0.25, 0.05, 0.50);
    vec3 VIOLET_BRIGHT = vec3(0.85, 0.30, 1.00);
    vec3 CYAN_DEEP     = vec3(0.02, 0.18, 0.50);
    vec3 CYAN_BRIGHT   = vec3(0.40, 0.92, 1.00);
    vec3 emberCol  = mix(EMBER_DEEP,   EMBER_BRIGHT,   swirl);
    vec3 orangeCol = mix(ORANGE_DEEP,  ORANGE_BRIGHT,  swirl);
    vec3 greenCol  = mix(GREEN_DEEP,   GREEN_BRIGHT,   swirl);
    vec3 violetCol = mix(VIOLET_DEEP,  VIOLET_BRIGHT,  swirl);
    vec3 cyanCol   = mix(CYAN_DEEP,    CYAN_BRIGHT,    swirl);
    emberCol = mix(emberCol, orangeCol, clamp(uTint,       0.0, 1.0));
    emberCol = mix(emberCol, greenCol,  clamp(uTint - 1.0, 0.0, 1.0));
    emberCol = mix(emberCol, violetCol, clamp(uTint - 2.0, 0.0, 1.0));
    emberCol = mix(emberCol, cyanCol,   clamp(uTint - 3.0, 0.0, 1.0));
    emberCol *= 0.45 + curtain * 0.95;

    /* Per-particle ignition threshold ∈ [0..1] so different
       particles flip at different uHeat values. seed.z varies
       per-particle so the boil is unsynchronised. */
    float ignitionT = seed.z;
    /* h = how far past this particle's ignition threshold uHeat
       has gone, 0..1 across a 0.20 window. */
    float h = smoothstep(ignitionT - 0.10, ignitionT + 0.10, uHeat);
    /* Two-stage blend: cyan → bright orange flash (the
       ignition moment), then flash → settled ember.  The flash
       is a triangle profile peaking right at h=0.5 so each
       particle briefly glows hot as it transitions. */
    float flashPulse = (1.0 - abs(h - 0.5) * 2.0);
    flashPulse = max(0.0, flashPulse);
    vec3 sunCol = mix(emberCol, IGNITION, flashPulse * 0.85);
    col = mix(col, sunCol, h);

    vColor = col;

    float bulgeFactor = max(0.0, shellGlow);
    float dentFactor  = max(0.0, -shellGlow);
    vAlpha = (0.55 + seed.y * 0.4) * (1.0 + bulgeFactor * 1.4 - dentFactor * 0.45) * uOpacity;
    /* Tap-to-burst explosion: each particle accelerates outward
       from origin proportional to uExplode (with a slight per-
       particle seed so the burst doesn't move as a rigid shell),
       and its alpha drops to zero so the field dissolves toward
       the camera rather than just zooming. */
    float burst = uExplode * (4.0 + seed.x * 3.0);
    pos *= 1.0 + burst;
    vAlpha *= 1.0 - smoothstep(0.0, 0.7, uExplode);

    /* === THE BREAK-APART (HALO section) =================
       Each particle peels off the sphere on its own staggered cue
       and streams to its landscape position.  All the sphere-side
       motion above (rotation, swirl, crater, tilt) rides the
       sphere path only; the landed particle just shimmers. */
    float tMix = smoothstep(seed.y * 0.35, seed.y * 0.35 + 0.65, uTerra);
    if (tMix > 0.001) {
      vec3 terraP = aTerra;
      terraP.y += sin(uTime * 0.55 + seed.x * 6.28318) * 0.012;
      pos = mix(pos, terraP, tMix);
      vColor = mix(vColor, aTerraCol, tMix);
      vAlpha = mix(vAlpha, 0.9 * uOpacity, tMix);
    }

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    /* Micro point sprites: ~1.0 to 2.4 px on screen with mild
       attenuation. Bulge particles get a slight size bump so
       the crater rim reads as a brighter, denser ripple.
       Landed landscape particles render a touch larger. */
    float sizeAtten = clamp(8.0 / -mvPosition.z, 0.55, 1.4);
    float sizeBoost = 1.0 + bulgeFactor * 0.9;
    float baseSize = mix(1.0 + seed.y * 1.4, 1.8 + seed.y * 1.7, tMix);
    gl_PointSize = baseSize * uPixelRatio * sizeAtten * sizeBoost;
    gl_Position = projectionMatrix * mvPosition;
  }
`,N=`
  varying vec3 vColor;
  varying float vAlpha;

  void main() {
    vec2 c = gl_PointCoord - 0.5;
    float d = length(c);
    if (d > 0.5) discard;
    /* Soft round sprite with bright core. */
    float a = smoothstep(0.5, 0.0, d) * vAlpha;
    vec3 col = vColor + vec3(smoothstep(0.18, 0.0, d) * 0.45);
    gl_FragColor = vec4(col, a);
  }
`,ee=`
  attribute vec3 seed;
  attribute vec3 aStartPos;
  uniform float uTime;
  uniform vec3 uMouse;
  uniform float uMouseInfluence;
  uniform float uPixelRatio;
  uniform vec2 uTilt;
  uniform float uIntroT;
  uniform float uHeat;
  uniform float uExtraRotation;
  uniform float uRingFlip;   /* X-axis tumble (radians) so the
                                ring rotates edge-on as the
                                reader scrolls past the manifesto. */
  uniform float uTint;       /* 0 = warm ring, 1 = violet ring. */
  uniform float uOpacity;    /* 1 = visible, 0 = invisible. Drives
                                the ring's independent fade so it
                                can appear/disappear separately
                                from the sphere. */
  uniform float uExplode;    /* 0 = at rest, 1 = fully exploded.
                                Ring particles fly outward and
                                fade in sync with the sphere's
                                burst. */
  uniform float uTerra;      /* the HALO break-apart — ring particles
                                stream into the landscape with the
                                sphere (mountain crests + stars). */
  attribute vec3 aTerra;
  attribute vec3 aTerraCol;
  varying vec3 vColor;
  varying float vAlpha;

  /* Favicon palette taken from public/favicon.svg gradient. */
  const vec3 FAV_CYAN = vec3(0.34, 0.88, 1.00);  /* #56E1FF */
  const vec3 FAV_BLUE = vec3(0.49, 0.66, 1.00);  /* #7DA8FF */
  /* Heat-mode ring palette — deep ember red → bright orange.
     Brightened (user request — was too dim on mobile). */
  const vec3 RING_EMBER  = vec3(1.00, 0.28, 0.08);
  const vec3 RING_ORANGE = vec3(1.00, 0.70, 0.20);

  vec3 rotateY(vec3 p, float a) {
    float c = cos(a), s = sin(a);
    return vec3(c * p.x + s * p.z, p.y, -s * p.x + c * p.z);
  }
  vec3 rotateX(vec3 p, float a) {
    float c = cos(a), s = sin(a);
    return vec3(p.x, c * p.y - s * p.z, s * p.y + c * p.z);
  }

  void main() {
    /* === INTRO RUSH-IN ===
       Match the sphere's rush-in behaviour; ring particles fly in
       from behind the camera into their ring positions. */
    float introEase = 1.0 - pow(1.0 - clamp(uIntroT, 0.0, 1.0), 3.0);
    vec3 pos = mix(aStartPos, position, introEase);

    /* === MOBILE TILT PARALLAX ===
       Same tilt as the sphere — slightly larger amplitude (0.32 vs
       0.22) so the ring feels like it leans more dramatically than
       the inner sphere, giving depth to the parallax. */
    pos = rotateY(pos, uTilt.x * 0.32);
    pos = rotateX(pos, uTilt.y * 0.32);

    /* === STAGE 1 — GLOBAL RING ORBIT ===
       Slow Z-axis rotation (in the ring's own plane). */
    float globalRot = uTime * 0.07 + uExtraRotation;
    float gc = cos(globalRot);
    float gs = sin(globalRot);
    pos = vec3(gc * pos.x - gs * pos.y, gs * pos.x + gc * pos.y, pos.z);

    /* === STAGE 1b — RING FLIP ===
       X-axis tumble so the ring rotates edge-on as the reader
       scrolls past the manifesto. uRingFlip is 0 in hero +
       manifesto, ramps to ~π in the section after, then holds. */
    pos = rotateX(pos, uRingFlip);

    /* === STAGE 2 — MOUSE INTERACTION ===
       Distance from this particle to the cursor's 3D position;
       proximity peaks at 1.0 right at the cursor and falls to 0
       at REACH_RING units away. uMouseInfluence keeps it gated
       to when the cursor is actually on / near the sphere. */
    float REACH_RING = 1.5;
    float distToCursor = length(pos - uMouse);
    float proximity = (1.0 - smoothstep(0.0, REACH_RING, distToCursor)) * uMouseInfluence;
    proximity = pow(proximity, 0.7);  /* soften the peak */

    /* Slight outward scatter — particles near the cursor lift
       radially out of the ring plane. */
    vec3 outFromCenter = normalize(vec3(pos.x, pos.y, 0.001));
    pos += outFromCenter * proximity * 0.18;
    pos.z += proximity * 0.06;

    /* Colour gradient — angular position + slow time cycle. */
    float gradient = sin(seed.x * 6.28318 + uTime * 0.4) * 0.5 + 0.5;
    vec3 col = mix(FAV_CYAN, FAV_BLUE, gradient);

    /* Per-particle brightness pulse. */
    float pulse = 0.65 + sin(seed.x * 12.566 + uTime * 0.7 + seed.z * 3.0) * 0.35;
    col *= pulse;

    /* Cursor proximity boost — particles near the cursor brighten
       toward near-white cyan and gain saturation. */
    col = mix(col, vec3(0.95, 1.00, 1.00), proximity * 0.6);
    col *= 1.0 + proximity * 0.9;

    /* === HEAT MODE — ring particles transition with the same
       per-particle ignition profile as the sphere shell so the
       cyan → ember handoff feels unified. Each particle has its
       own seed.z threshold and flashes through bright orange
       on the way. */
    vec3 ringHot = mix(RING_EMBER, RING_ORANGE, gradient) * pulse;
    /* Five-stop ring palette in sync with the sphere:
         uTint 0 → 1 : ember/orange → orange (Mismatch)
         uTint 1 → 2 : orange       → green  (MeetVega)
         uTint 2 → 3 : green        → violet (AnyFacility)
         uTint 3 → 4 : violet       → cyan   (Compare) */
    /* Orange + violet ring stops bumped brighter (user request);
       green + cyan kept as-is. */
    vec3 ringOrange = mix(vec3(0.70, 0.28, 0.04), vec3(1.00, 0.72, 0.22), gradient) * pulse;
    vec3 ringGreen  = mix(vec3(0.04, 0.30, 0.10), vec3(0.25, 1.00, 0.50), gradient) * pulse;
    vec3 ringViolet = mix(vec3(0.45, 0.10, 0.85), vec3(0.85, 0.35, 1.00), gradient) * pulse;
    vec3 ringCyan   = mix(vec3(0.04, 0.30, 0.65), vec3(0.40, 0.95, 1.00), gradient) * pulse;
    ringHot = mix(ringHot, ringOrange, clamp(uTint,       0.0, 1.0));
    ringHot = mix(ringHot, ringGreen,  clamp(uTint - 1.0, 0.0, 1.0));
    ringHot = mix(ringHot, ringViolet, clamp(uTint - 2.0, 0.0, 1.0));
    ringHot = mix(ringHot, ringCyan,   clamp(uTint - 3.0, 0.0, 1.0));
    vec3 ringFlash = vec3(1.00, 0.55, 0.10);
    float ringIgnitionT = seed.z;
    float rh = smoothstep(ringIgnitionT - 0.10, ringIgnitionT + 0.10, uHeat);
    float ringFlashPulse = max(0.0, 1.0 - abs(rh - 0.5) * 2.0);
    vec3 ringSettled = mix(ringHot, ringFlash, ringFlashPulse * 0.7);
    ringSettled = mix(ringSettled, vec3(1.0, 0.95, 0.7), proximity * 0.5);
    col = mix(col, ringSettled, rh);

    vColor = col;
    vAlpha = (0.8 + seed.y * 0.2) * (1.0 + proximity * 0.6) * uOpacity;
    /* Mirror the sphere's burst — outward push + alpha fade. */
    float ringBurst = uExplode * (4.0 + seed.x * 3.0);
    pos *= 1.0 + ringBurst;
    vAlpha *= 1.0 - smoothstep(0.0, 0.7, uExplode);

    /* === THE BREAK-APART (HALO section) — ring joins the sphere,
       its particles streaming to the crests + sky. */
    float tMix = smoothstep(seed.y * 0.35, seed.y * 0.35 + 0.65, uTerra);
    if (tMix > 0.001) {
      vec3 terraP = aTerra;
      terraP.y += sin(uTime * 0.55 + seed.x * 6.28318) * 0.012;
      pos = mix(pos, terraP, tMix);
      vColor = mix(vColor, aTerraCol, tMix);
      vAlpha = mix(vAlpha, 0.9 * uOpacity, tMix);
    }

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    float sizeAtten = clamp(8.0 / -mvPosition.z, 0.55, 1.4);
    /* Size bumps up where the cursor is — bright cluster reads
       larger, like fireflies catching light. */
    float sizeBoost = 1.0 + proximity * 0.7;
    float baseSize = mix(1.3 + seed.y * 1.1, 1.8 + seed.y * 1.6, tMix);
    gl_PointSize = baseSize * uPixelRatio * sizeAtten * sizeBoost;
    gl_Position = projectionMatrix * mvPosition;
  }
`;function P(){let{camera:e,size:t}=u();return(0,f.useEffect)(()=>{if(!(e instanceof c))return;let n=t.width/t.height,r=e.fov*Math.PI/180,i=n<1?b+.15:C+.4,a=Math.min(n,1),o=i/(Math.tan(r/2)*a);e.position.z=Math.max(6.4,o),e.updateProjectionMatrix()},[e,t.width,t.height]),null}var F=2.6;function I({heat:e=0,heatRef:t,rotationRef:n,ringFlipRef:c,tintRef:l,sphereOpacityRef:v,ringOpacityRef:T,ringScaleRef:E,ringYActiveRef:D,ringFig8ActiveRef:O,explodeRef:k,terraRef:A}){let P=(0,f.useRef)(null),I=(0,f.useRef)(null),L=(0,f.useRef)(null),{camera:te,mouse:R}=u(),ne=(0,f.useRef)(performance.now()/1e3),z=(0,f.useRef)(!1),B=(0,f.useRef)(new a(0,0,b)),V=(0,f.useRef)(new a(0,0,b)),H=(0,f.useRef)(0),U=(0,f.useRef)(0),re=(0,f.useRef)(!1),W=(0,f.useMemo)(()=>new i(0,0),[]),G=(0,f.useRef)(!1),K=(0,f.useRef)(0),q=(0,f.useMemo)(()=>new o,[]),J=(0,f.useMemo)(()=>new r(new a(0,0,0),b),[]),Y=(0,f.useMemo)(()=>new i,[]),X=(0,f.useMemo)(()=>new a,[]),Z=(0,f.useMemo)(()=>new a,[]),Q=(0,f.useMemo)(()=>new a,[]),{positions:ie,startPositions:ae,seeds:oe,terra:se,terraCol:ce}=(0,f.useMemo)(()=>{let e=new Float32Array(y*3),t=new Float32Array(y*3),n=new Float32Array(y*3);for(let r=0;r<y;r++){let i=r*3,a=Math.random(),o=Math.random(),s=a*Math.PI*2,c=Math.acos(2*o-1),l=b+(Math.random()-.5)*x,u=l*Math.sin(c)*Math.cos(s),d=l*Math.sin(c)*Math.sin(s),f=l*Math.cos(c);e[i]=u,e[i+1]=d,e[i+2]=f;let p=9+Math.random()*6,m=1.6+Math.random()*1.2;t[i]=u*m+(Math.random()-.5)*.6,t[i+1]=d*m+(Math.random()-.5)*.6+.4,t[i+2]=f+p,n[i]=Math.random(),n[i+1]=Math.random(),n[i+2]=Math.random()}let{terra:r,terraCol:i}=j(y,!1);return{positions:e,startPositions:t,seeds:n,terra:r,terraCol:i}},[]);(0,f.useEffect)(()=>{let e=typeof window<`u`&&(`ontouchstart`in window||(navigator.maxTouchPoints??0)>0);if(G.current=e,!e||window.DeviceOrientationEvent===void 0)return;let t=null,n=null,r=.006,i=e=>{if(e.beta==null||e.gamma==null)return;t==null?(t=e.beta,n=e.gamma):(t=t*(1-r)+e.beta*r,n=n*(1-r)+e.gamma*r);let i=(e.beta-t)/16,a=(e.gamma-n)/16,o=(window.screen?.orientation?.angle??0)%360;if(o===90){let e=i;i=-a,a=e}else if(o===270||o===-90){let e=i;i=a,a=-e}else o===180&&(i=-i,a=-a);H.current=Math.max(-1,Math.min(1,-a)),U.current=Math.max(-1,Math.min(1,i)),re.current=!0};return window.addEventListener(`deviceorientation`,i),()=>{window.removeEventListener(`deviceorientation`,i)}},[]);let{torusPositions:le,torusStartPositions:$,torusSeeds:ue,torusTerra:de,torusTerraCol:fe}=(0,f.useMemo)(()=>{let e=new Float32Array(S*3),t=new Float32Array(S*3),n=new Float32Array(S*3);for(let r=0;r<S;r++){let i=r*3,a=Math.random()*Math.PI*2,o=Math.random()*Math.PI*2,s=w*(.85+Math.random()*.3),c=(C+s*Math.cos(o))*Math.cos(a),l=(C+s*Math.cos(o))*Math.sin(a),u=s*Math.sin(o);e[i]=c,e[i+1]=l,e[i+2]=u;let d=12+Math.random()*6,f=1.4+Math.random()*1;t[i]=c*f+(Math.random()-.5)*.5,t[i+1]=l*f+(Math.random()-.5)*.5+.4,t[i+2]=u+d,n[i]=a/(Math.PI*2),n[i+1]=Math.random(),n[i+2]=Math.random()}let{terra:r,terraCol:i}=j(S,!0);return{torusPositions:e,torusStartPositions:t,torusSeeds:n,torusTerra:r,torusTerraCol:i}},[]);return d((r,i)=>{let a=1;if(!z.current){let e=performance.now()/1e3-ne.current;a=Math.max(0,Math.min(1,e/F)),a>=1&&(z.current=!0)}let o=t?.current??e,u=n?.current??0,d=c?.current??0,f=l?.current??0,p=v?.current??1,y=T?.current??1;if(P.current&&(P.current.uniforms.uTime.value=r.clock.elapsedTime,P.current.uniforms.uPixelRatio.value=Math.min(window.devicePixelRatio||1,1.5),P.current.uniforms.uIntroT.value=a,P.current.uniforms.uHeat.value=o,P.current.uniforms.uExtraRotation.value=u,P.current.uniforms.uTint.value=f,P.current.uniforms.uOpacity.value=p,P.current.uniforms.uExplode.value=k?.current??0,P.current.uniforms.uTerra.value=A?.current??0),I.current&&(I.current.uniforms.uIntroT.value=a,I.current.uniforms.uHeat.value=o,I.current.uniforms.uExtraRotation.value=u,I.current.uniforms.uRingFlip.value=d,I.current.uniforms.uTint.value=f,I.current.uniforms.uOpacity.value=y,I.current.uniforms.uExplode.value=k?.current??0,I.current.uniforms.uTerra.value=A?.current??0),L.current){let e=E?.current??1;L.current.scale.set(e,e,e);let t=D?.current??0;g.setFromAxisAngle(h,t);let n=O?.current??0;n>.001&&n<.999&&(_.setFromAxisAngle(m,n*2*Math.PI),g.multiply(_)),L.current.quaternion.copy(g)}if(G.current){W.x=s.lerp(W.x,H.current,.08),W.y=s.lerp(W.y,U.current,.08),P.current&&(P.current.uniforms.uTilt.value.copy(W),P.current.uniforms.uMouseInfluence.value=0),I.current&&(I.current.uniforms.uTilt.value.copy(W),I.current.uniforms.uMouseInfluence.value=0,I.current.uniforms.uTime.value=r.clock.elapsedTime,I.current.uniforms.uPixelRatio.value=Math.min(window.devicePixelRatio||1,1.5));return}Y.set(R.x,R.y),q.setFromCamera(Y,te);let b=q.ray;X.subVectors(J.center,b.origin);let x=Math.max(0,X.dot(b.direction));Z.copy(b.direction).multiplyScalar(x).add(b.origin);let S=Z.distanceTo(J.center),C;if(S<=J.radius)b.intersectSphere(J,V.current),C=1;else{Q.copy(Z).sub(J.center).normalize(),V.current.copy(J.center).add(Q.multiplyScalar(J.radius));let e=S-J.radius;C=Math.max(0,1-e/1)}B.current.lerp(V.current,.32),K.current=s.lerp(K.current,C,.12),P.current&&(P.current.uniforms.uMouse.value.copy(B.current),P.current.uniforms.uMouseInfluence.value=K.current),I.current&&(I.current.uniforms.uTime.value=r.clock.elapsedTime,I.current.uniforms.uPixelRatio.value=Math.min(window.devicePixelRatio||1,1.5),I.current.uniforms.uMouse.value.copy(B.current),I.current.uniforms.uMouseInfluence.value=K.current)}),(0,p.jsxs)(p.Fragment,{children:[(0,p.jsxs)(`points`,{children:[(0,p.jsxs)(`bufferGeometry`,{children:[(0,p.jsx)(`bufferAttribute`,{attach:`attributes-position`,args:[ie,3]}),(0,p.jsx)(`bufferAttribute`,{attach:`attributes-aStartPos`,args:[ae,3]}),(0,p.jsx)(`bufferAttribute`,{attach:`attributes-seed`,args:[oe,3]}),(0,p.jsx)(`bufferAttribute`,{attach:`attributes-aTerra`,args:[se,3]}),(0,p.jsx)(`bufferAttribute`,{attach:`attributes-aTerraCol`,args:[ce,3]})]}),(0,p.jsx)(`shaderMaterial`,{ref:P,vertexShader:M,fragmentShader:N,uniforms:{uTime:{value:0},uMouse:{value:new a(0,0,b)},uMouseInfluence:{value:0},uPixelRatio:{value:1},uTilt:{value:new i(0,0)},uIntroT:{value:0},uHeat:{value:0},uExtraRotation:{value:0},uTint:{value:0},uOpacity:{value:1},uExplode:{value:0},uTerra:{value:0}},transparent:!0,depthWrite:!1,blending:2,toneMapped:!1})]}),(0,p.jsx)(`group`,{ref:L,children:(0,p.jsxs)(`points`,{children:[(0,p.jsxs)(`bufferGeometry`,{children:[(0,p.jsx)(`bufferAttribute`,{attach:`attributes-position`,args:[le,3]}),(0,p.jsx)(`bufferAttribute`,{attach:`attributes-aStartPos`,args:[$,3]}),(0,p.jsx)(`bufferAttribute`,{attach:`attributes-seed`,args:[ue,3]}),(0,p.jsx)(`bufferAttribute`,{attach:`attributes-aTerra`,args:[de,3]}),(0,p.jsx)(`bufferAttribute`,{attach:`attributes-aTerraCol`,args:[fe,3]})]}),(0,p.jsx)(`shaderMaterial`,{ref:I,vertexShader:ee,fragmentShader:N,uniforms:{uTime:{value:0},uMouse:{value:new a(0,0,b)},uMouseInfluence:{value:0},uPixelRatio:{value:1},uTilt:{value:new i(0,0)},uIntroT:{value:0},uHeat:{value:0},uExtraRotation:{value:0},uRingFlip:{value:0},uTint:{value:0},uOpacity:{value:1},uExplode:{value:0},uTerra:{value:0}},transparent:!0,depthWrite:!1,blending:2,toneMapped:!1})]})})]})}export{P as n,I as t};