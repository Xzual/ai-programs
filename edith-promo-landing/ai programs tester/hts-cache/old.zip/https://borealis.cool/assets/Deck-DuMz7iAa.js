import{a as e}from"./chunk-BNv3lrIs.js";import{t}from"./react-BFwN_vxz.js";import{t as n}from"./jsx-runtime-kJazARoa.js";import{t as r}from"./DeckGlobe-CCs3rtwn.js";var i=e(t(),1),a=n(),o=[{badge:`00 · Borealis · AGT-USA`,title:(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`div`,{className:`text-white`,children:`5× the cooling.`}),(0,a.jsx)(`div`,{className:`italic text-white/80`,children:`Same footprint.`})]}),body:(0,a.jsxs)(`div`,{className:`mt-12 grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-3xl`,children:[(0,a.jsx)(s,{k:`5×`,v:`Cooling vs. CRAC`}),(0,a.jsx)(s,{k:`14 days`,v:`Site-ready install`}),(0,a.jsx)(s,{k:`$700K/yr`,v:`Energy saved · 2 MW hall`})]})},{badge:`01 · Why now`,title:(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`div`,{className:`text-white`,children:`AI is melting your rack.`}),(0,a.jsx)(`div`,{className:`italic text-white/70`,children:`Legacy cooling can’t keep up.`})]}),body:(0,a.jsxs)(`ul`,{className:`mt-10 space-y-4 max-w-2xl font-mono text-[13px] tracking-[0.04em] text-white/75`,children:[(0,a.jsx)(`li`,{children:`· New AI racks are denser than any CRAC can cool.`}),(0,a.jsx)(`li`,{children:`· The fix today: four vendors, a custom controller, nine months of install.`}),(0,a.jsx)(`li`,{children:`· Borealis drops in with one vendor and delivers 5× the cooling.`})]})},{badge:`02 · The mismatch`,title:(0,a.jsx)(`div`,{className:`text-white`,children:`Your AC only handles 120 kW.`}),body:(0,a.jsxs)(`ul`,{className:`mt-10 space-y-4 max-w-2xl font-mono text-[13px] tracking-[0.04em] text-white/75`,children:[(0,a.jsx)(`li`,{children:`· 1 AI rack demands 132 kW. You’re already underwater.`}),(0,a.jsx)(`li`,{children:`· Most buildings are maxed before they even start.`}),(0,a.jsx)(`li`,{children:`· Air conditioning was designed for offices, not AI.`})]})},{badge:`03 · The Vega system`,title:(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`div`,{className:`text-white`,children:`Four parts.`}),(0,a.jsx)(`div`,{className:`italic text-white/70`,children:`One controller.`})]}),body:(0,a.jsxs)(`div`,{className:`mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-5xl`,children:[(0,a.jsx)(c,{tag:`01`,title:`Rack`,sub:`Rear-door heat exchanger`,body:`Servers slide in. Cold water takes the heat.`}),(0,a.jsx)(c,{tag:`02`,title:`CDU`,sub:`Pumping station`,body:`Twin multistage pumps. Sanitary stainless plumbing.`}),(0,a.jsx)(c,{tag:`03`,title:`Condenser`,sub:`Air-cooled coils`,body:`Rejects to ambient. Single closed thermal path.`}),(0,a.jsx)(c,{tag:`04`,title:`Chiller`,sub:`Refrigerant cooling`,body:`Lifts heat out of the building. One refrigerant loop.`})]})},{badge:`04 · Borealis CDU`,title:(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`div`,{className:`text-white`,children:`The brain`}),(0,a.jsx)(`div`,{className:`italic text-white/70`,children:`next to the rack.`})]}),body:(0,a.jsxs)(`div`,{className:`mt-10 grid grid-cols-1 sm:grid-cols-2 gap-x-12 gap-y-3 max-w-3xl font-mono text-[13px] tracking-[0.04em]`,children:[(0,a.jsx)(l,{k:`Pumps`,v:`Vertical multistage, IE5, N+1`}),(0,a.jsx)(l,{k:`Connections`,v:`DN50 tri-clamp, PN25`}),(0,a.jsx)(l,{k:`Sensors`,v:`Digital flow / pressure / vibration`}),(0,a.jsx)(l,{k:`Plumbing`,v:`Sanitary stainless, sealless dielectric`}),(0,a.jsx)(l,{k:`Module (dual / triple)`,v:`276 / 414 kW`}),(0,a.jsx)(l,{k:`Standard CDU (3 modules)`,v:`829 kW`}),(0,a.jsx)(l,{k:`Max CDU (6 modules)`,v:`1.66 MW`}),(0,a.jsx)(l,{k:`Fleet`,v:`Multi-CDU to 5 MW+`}),(0,a.jsx)(l,{k:`Rating method`,v:`OCP 5 °C · 2.88 LPM/kW`}),(0,a.jsx)(l,{k:`NPSH margin`,v:`≥ 2.0 m`})]})},{badge:`05 · Operating modes`,title:(0,a.jsx)(`div`,{className:`text-white`,children:`Three modes. One cabinet.`}),body:(0,a.jsxs)(`div`,{className:`mt-10 grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-5xl`,children:[(0,a.jsx)(u,{tag:`A`,name:`Glycol loop`,body:`Vertical multistage pumps, primary water-glycol mixture. The reliable baseline mode.`}),(0,a.jsx)(u,{tag:`B`,name:`Two-phase dielectric`,body:`EEV-controlled refrigerant for the highest density racks.`}),(0,a.jsx)(u,{tag:`C`,name:`Dual stack`,body:`Modes A + B combined for hybrid loads. Failover between the two.`})]})},{badge:`06 · Validated`,title:(0,a.jsx)(`div`,{className:`text-white`,children:`The pilot ran. The numbers held up.`}),body:(0,a.jsxs)(`div`,{className:`mt-10 grid grid-cols-1 sm:grid-cols-2 gap-x-12 gap-y-3 max-w-3xl font-mono text-[13px] tracking-[0.04em]`,children:[(0,a.jsx)(l,{k:`Capacity hold`,v:`≥ 95% of rated, all modes`}),(0,a.jsx)(l,{k:`Transient response`,v:`3 to 5 s on load steps`}),(0,a.jsx)(l,{k:`Temperature overshoot`,v:`≤ 0.5 °C`}),(0,a.jsx)(l,{k:`Mechanical Load Coefficient`,v:`≤ 10 W per kW cooled`}),(0,a.jsx)(l,{k:`Acoustics`,v:`≤ 65 dBA @ 1 m`}),(0,a.jsx)(l,{k:`Compliance`,v:`ASHRAE 90.4 · UL 508A · ASME B31.3`}),(0,a.jsx)(l,{k:`Engineering heritage`,v:`35+ yrs AGT-USA`}),(0,a.jsx)(l,{k:`Systems shipped`,v:`5,000+`})]})},{badge:`07 · The math`,title:(0,a.jsx)(`div`,{className:`text-white`,children:`Cooling shouldn’t cost compute.`}),body:(0,a.jsxs)(`div`,{className:`mt-10 max-w-4xl`,children:[(0,a.jsx)(`div`,{className:`font-mono text-[12px] tracking-[0.22em] uppercase text-white/55 mb-6`,children:`$6.5M per AI rack. Every month it runs throttled, you’re burning compute.`}),(0,a.jsx)(d,{a:`Multiple vendors.`,b:`One responsible system.`}),(0,a.jsx)(d,{a:`Months of field assembly.`,b:`Days to commission.`}),(0,a.jsx)(d,{a:`Cools the room.`,b:`Cools the rack.`}),(0,a.jsx)(d,{a:`30% overhead on cooling.`,b:`That power back to compute.`}),(0,a.jsx)(`div`,{className:`mt-8 font-mono text-[14px] tracking-[0.04em] text-white`,children:`One project. One quote.`})]})},{badge:`08 · Ways in`,title:(0,a.jsx)(`div`,{className:`text-white`,children:`Three ways in.`}),body:(0,a.jsxs)(`div`,{className:`mt-10 grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-5xl`,children:[(0,a.jsx)(f,{tier:`Rear-door HX`,range:`Up to 132 kW`,per:`per rack`,body:`Retrofit a single rack. The smallest viable Borealis deployment.`}),(0,a.jsx)(f,{tier:`Borealis CDU`,range:`Up to 829 kW`,per:`per unit`,body:`The pumping station alone. Drop into an existing chilled-water loop.`,accent:!0}),(0,a.jsx)(f,{tier:`Complete Vega`,range:`500 kW`,per:`turnkey`,body:`All four parts: RDHX, CDU, condenser, chiller. One vendor. One controller. Quoted per site.`})]})},{badge:`09 · Any facility`,title:(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`div`,{className:`text-white`,children:`One system,`}),(0,a.jsx)(`div`,{className:`italic text-white/70`,children:`any facility.`})]}),body:(0,a.jsxs)(`ul`,{className:`mt-10 grid grid-cols-1 sm:grid-cols-2 gap-x-12 gap-y-3 max-w-3xl font-mono text-[13px] tracking-[0.04em] text-white/75`,children:[(0,a.jsx)(`li`,{children:`· High-density AI & data centers`}),(0,a.jsx)(`li`,{children:`· Hospitals & healthcare`}),(0,a.jsx)(`li`,{children:`· Research & university labs`}),(0,a.jsx)(`li`,{children:`· Industrial & manufacturing`}),(0,a.jsx)(`li`,{children:`· Brownfield retrofits & legacy buildings`}),(0,a.jsx)(`li`,{children:`· Anywhere heat is the bottleneck`})]})},{badge:`10 · Get cooling`,title:(0,a.jsx)(`div`,{className:`text-white`,children:`Let’s talk.`}),body:(0,a.jsx)(`div`,{className:`mt-12 font-mono text-[18px] tracking-[0.04em]`,children:(0,a.jsx)(`a`,{href:`https://borealis.cool`,className:`text-cyan-300 hover:text-cyan-100 underline-offset-4 hover:underline`,children:`borealis.cool`})})}];function s({k:e,v:t}){return(0,a.jsxs)(`div`,{className:`border border-white/12 bg-black/40 backdrop-blur-sm px-5 py-4 rounded-sm`,children:[(0,a.jsx)(`div`,{className:`font-display text-3xl text-cyan-300 leading-none`,children:e}),(0,a.jsx)(`div`,{className:`mt-2 font-mono text-[10px] tracking-[0.22em] uppercase text-white/55`,children:t})]})}function c({tag:e,title:t,sub:n,body:r}){return(0,a.jsxs)(`div`,{className:`border border-white/12 bg-black/40 backdrop-blur-sm px-5 py-4 rounded-sm`,children:[(0,a.jsx)(`div`,{className:`font-mono text-[10px] tracking-[0.22em] uppercase text-cyan-300`,children:e}),(0,a.jsx)(`div`,{className:`font-display text-xl text-white mt-1`,children:t}),(0,a.jsx)(`div`,{className:`font-mono text-[10px] tracking-[0.22em] uppercase text-white/55 mt-0.5`,children:n}),(0,a.jsx)(`div`,{className:`font-mono text-[12px] tracking-[0.02em] text-white/65 mt-3 leading-snug`,children:r})]})}function l({k:e,v:t}){return(0,a.jsxs)(`div`,{className:`flex items-baseline justify-between gap-4 border-b border-white/8 py-2`,children:[(0,a.jsx)(`span`,{className:`text-white/55 uppercase tracking-[0.18em] text-[10px]`,children:e}),(0,a.jsx)(`span`,{className:`text-white`,children:t})]})}function u({tag:e,name:t,body:n}){return(0,a.jsxs)(`div`,{className:`border border-white/12 bg-black/40 backdrop-blur-sm px-5 py-5 rounded-sm`,children:[(0,a.jsxs)(`div`,{className:`font-mono text-[10px] tracking-[0.22em] uppercase text-cyan-300`,children:[`Mode `,e]}),(0,a.jsx)(`div`,{className:`font-display text-lg text-white mt-1`,children:t}),(0,a.jsx)(`div`,{className:`font-mono text-[12px] tracking-[0.02em] text-white/65 mt-3 leading-snug`,children:n})]})}function d({a:e,b:t}){return(0,a.jsxs)(`div`,{className:`grid grid-cols-1 sm:grid-cols-2 gap-x-6 py-2 border-b border-white/8 font-mono text-[13px] tracking-[0.04em]`,children:[(0,a.jsx)(`div`,{className:`text-white/45 line-through decoration-white/25`,children:e}),(0,a.jsx)(`div`,{className:`text-white`,children:t})]})}function f({tier:e,range:t,per:n,body:r,accent:i}){return(0,a.jsxs)(`div`,{className:[`border bg-black/40 backdrop-blur-sm px-5 py-5 rounded-sm`,i?`border-cyan-300/55`:`border-white/12`].join(` `),children:[(0,a.jsx)(`div`,{className:`font-mono text-[10px] tracking-[0.22em] uppercase text-cyan-300`,children:e}),(0,a.jsx)(`div`,{className:`font-display text-2xl text-white mt-2`,children:t}),(0,a.jsx)(`div`,{className:`font-mono text-[10px] tracking-[0.22em] uppercase text-white/55 mt-0.5`,children:n}),(0,a.jsx)(`div`,{className:`font-mono text-[12px] tracking-[0.02em] text-white/65 mt-3 leading-snug`,children:r})]})}function p(){let e=`/borealis-sphere.png`;return(0,a.jsxs)(`div`,{className:`deck-print`,children:[(0,a.jsxs)(`section`,{className:`deck-print-page deck-print-cover`,children:[(0,a.jsx)(`img`,{src:e,className:`deck-print-cover-sphere`,alt:``}),(0,a.jsx)(`div`,{className:`deck-print-corner deck-print-corner--tl`,"aria-hidden":!0}),(0,a.jsx)(`div`,{className:`deck-print-corner deck-print-corner--tr`,"aria-hidden":!0}),(0,a.jsx)(`div`,{className:`deck-print-corner deck-print-corner--bl`,"aria-hidden":!0}),(0,a.jsx)(`div`,{className:`deck-print-corner deck-print-corner--br`,"aria-hidden":!0}),(0,a.jsx)(`div`,{className:`deck-print-cover-wordmark`,children:`BOREALIS`}),(0,a.jsx)(`div`,{className:`deck-print-cover-url`,children:`borealis.cool`})]}),o.map((t,n)=>(0,a.jsxs)(`section`,{className:`deck-print-page`,children:[(0,a.jsx)(`img`,{src:e,className:`deck-print-bg-sphere`,alt:``}),(0,a.jsx)(`div`,{className:`deck-print-bg-veil`,"aria-hidden":!0}),(0,a.jsx)(`div`,{className:`deck-print-corner deck-print-corner--tl`,"aria-hidden":!0}),(0,a.jsx)(`div`,{className:`deck-print-corner deck-print-corner--tr`,"aria-hidden":!0}),(0,a.jsx)(`div`,{className:`deck-print-corner deck-print-corner--bl`,"aria-hidden":!0}),(0,a.jsx)(`div`,{className:`deck-print-corner deck-print-corner--br`,"aria-hidden":!0}),(0,a.jsxs)(`div`,{className:`deck-print-inner`,children:[(0,a.jsxs)(`div`,{className:`deck-print-header`,children:[(0,a.jsx)(`span`,{className:`deck-print-badge`,children:t.badge}),(0,a.jsxs)(`span`,{className:`deck-print-counter`,children:[String(n+1).padStart(2,`0`),(0,a.jsxs)(`span`,{className:`deck-print-counter-dim`,children:[` / `,String(o.length).padStart(2,`0`)]})]})]}),(0,a.jsxs)(`div`,{className:`deck-print-body`,children:[(0,a.jsx)(`div`,{className:`deck-print-title`,children:t.title}),t.body]}),(0,a.jsxs)(`div`,{className:`deck-print-footer`,children:[(0,a.jsx)(`span`,{className:`deck-print-wordmark`,children:`BOREALIS`}),(0,a.jsx)(`span`,{className:`deck-print-url`,children:`borealis.cool`})]})]})]},n)),(0,a.jsx)(`style`,{children:`
        @page { size: letter landscape; margin: 0; }
        html, body { background: #000 !important; margin: 0; padding: 0; }
        .deck-print { background: #000; color: #fff; font-family: var(--font-display, "PP Neue Machina", sans-serif); }
        .deck-print-page {
          width: 11in;
          height: 8.5in;
          position: relative;
          overflow: hidden;
          page-break-after: always;
          break-after: page;
          background: #000;
          box-sizing: border-box;
        }
        .deck-print-page:last-of-type { page-break-after: auto; break-after: auto; }

        /* ===== COVER PAGE — full-bleed sphere + centred BOREALIS ===== */
        .deck-print-cover {
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .deck-print-cover-sphere {
          position: absolute;
          top: 50%;
          left: 50%;
          width: 7.5in;
          height: 7.5in;
          transform: translate(-50%, -50%);
          object-fit: contain;
          opacity: 1;
          /* Software-WebGL captures the sphere VERY dim — boost
             brightness + saturation so the printed cover matches
             the on-screen (hardware-accelerated) render. */
          filter: brightness(2.4) saturate(2.2) contrast(1.15)
                  drop-shadow(0 0 28px rgba(94, 234, 255, 0.18));
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }
        .deck-print-cover-wordmark {
          position: relative;
          z-index: 3;
          font-family: "PP Neue Machina", sans-serif;
          font-weight: 700;
          font-size: 110px;
          letter-spacing: -0.02em;
          color: #fff;
          text-shadow: 0 0 32px rgba(0,0,0,0.45);
        }
        .deck-print-cover-url {
          position: absolute;
          left: 0;
          right: 0;
          bottom: 0.55in;
          text-align: center;
          z-index: 3;
          font-family: "JetBrains Mono", ui-monospace, monospace;
          font-size: 11px;
          letter-spacing: 0.32em;
          text-transform: uppercase;
          color: rgba(255, 255, 255, 0.6);
        }

        /* ===== CONTENT SLIDES — sphere centred, dimmed, with
                veil so text reads cleanly over it ===== */
        .deck-print-bg-sphere {
          position: absolute;
          top: 50%;
          left: 50%;
          width: 6.2in;
          height: 6.2in;
          transform: translate(-50%, -50%);
          object-fit: contain;
          opacity: 0.85;
          filter: brightness(2.2) saturate(2) contrast(1.1);
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }
        .deck-print-bg-veil {
          position: absolute;
          inset: 0;
          background:
            radial-gradient(ellipse at 50% 50%, transparent 28%, rgba(0,0,0,0.55) 65%, rgba(0,0,0,0.85) 100%);
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }
        .deck-print-corner {
          position: absolute;
          width: 0.45in;
          height: 0.45in;
          border-color: rgba(94,234,255,0.7);
          border-style: solid;
          border-width: 0;
        }
        .deck-print-corner--tl { top: 0.4in; left: 0.4in; border-left-width: 1.4px; border-top-width: 1.4px; }
        .deck-print-corner--tr { top: 0.4in; right: 0.4in; border-right-width: 1.4px; border-top-width: 1.4px; }
        .deck-print-corner--bl { bottom: 0.4in; left: 0.4in; border-left-width: 1.4px; border-bottom-width: 1.4px; }
        .deck-print-corner--br { bottom: 0.4in; right: 0.4in; border-right-width: 1.4px; border-bottom-width: 1.4px; }
        .deck-print-inner {
          position: relative;
          z-index: 2;
          height: 100%;
          padding: 0.7in 0.9in;
          display: flex;
          flex-direction: column;
          box-sizing: border-box;
        }
        .deck-print-header {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
          font-family: "JetBrains Mono", ui-monospace, monospace;
          font-size: 9px;
          letter-spacing: 0.26em;
          text-transform: uppercase;
        }
        .deck-print-badge { color: #5eeaff; }
        .deck-print-counter { color: #fff; }
        .deck-print-counter-dim { color: rgba(255,255,255,0.35); }
        .deck-print-body {
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
          max-width: 9.2in;
          margin-top: 0.3in;
        }
        .deck-print-title {
          font-family: "PP Neue Machina", sans-serif;
          font-weight: 700;
          font-size: 56px;
          line-height: 0.95;
          letter-spacing: -0.02em;
          margin-bottom: 0.3in;
        }
        .deck-print-title .italic { font-style: italic; font-weight: 400; }
        .deck-print-footer {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
        }
        .deck-print-wordmark {
          font-family: "PP Neue Machina", sans-serif;
          font-weight: 700;
          font-size: 14px;
          letter-spacing: 0.32em;
        }
        .deck-print-url {
          font-family: "JetBrains Mono", ui-monospace, monospace;
          font-size: 9px;
          letter-spacing: 0.22em;
          text-transform: uppercase;
          color: rgba(255,255,255,0.55);
        }
        @media print {
          .deck-print-bg { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .deck-print-page { box-shadow: none; }
        }
      `})]})}function m(){return typeof window<`u`&&new URLSearchParams(window.location.search).get(`print`)===`1`?(0,a.jsx)(p,{}):(0,a.jsx)(h,{})}function h(){let[e,t]=(0,i.useState)(0),n=o.length,s=(0,i.useCallback)(e=>{t(t=>Math.max(0,Math.min(n-1,t+e)))},[n]),c=(0,i.useCallback)(e=>{t(Math.max(0,Math.min(n-1,e)))},[n]);(0,i.useEffect)(()=>{let e=e=>{e.key===`ArrowRight`||e.key===` `||e.key===`PageDown`?(e.preventDefault(),s(1)):e.key===`ArrowLeft`||e.key===`PageUp`?(e.preventDefault(),s(-1)):e.key===`Home`?c(0):e.key===`End`?c(n-1):/^[1-9]$/.test(e.key)?c(parseInt(e.key,10)-1):e.key===`0`&&c(9)};return window.addEventListener(`keydown`,e),()=>window.removeEventListener(`keydown`,e)},[s,c,n]);let l=o[e];return(0,a.jsxs)(`div`,{className:`relative min-h-screen w-full bg-black text-white overflow-hidden font-display`,children:[(0,a.jsx)(r,{slide:e,totalSlides:n}),(0,a.jsx)(g,{pos:`tl`}),(0,a.jsx)(g,{pos:`tr`}),(0,a.jsx)(g,{pos:`bl`}),(0,a.jsx)(g,{pos:`br`}),(0,a.jsx)(`button`,{type:`button`,onClick:()=>s(-1),"aria-label":`Previous slide`,className:`fixed left-0 top-0 bottom-0 w-1/5 z-10 cursor-w-resize bg-transparent`}),(0,a.jsx)(`button`,{type:`button`,onClick:()=>s(1),"aria-label":`Next slide`,className:`fixed right-0 top-0 bottom-0 w-1/5 z-10 cursor-e-resize bg-transparent`}),(0,a.jsxs)(`div`,{className:`relative z-20 min-h-screen flex flex-col px-8 sm:px-12 lg:px-20 py-12 sm:py-16`,children:[(0,a.jsxs)(`div`,{className:`flex items-start justify-between gap-6`,children:[(0,a.jsx)(`div`,{className:`font-mono text-[10px] tracking-[0.26em] uppercase text-cyan-300`,children:l.badge}),(0,a.jsxs)(`div`,{className:`font-mono text-[10px] tracking-[0.26em] uppercase text-white/55`,children:[(0,a.jsx)(`span`,{className:`text-white`,children:String(e+1).padStart(2,`0`)}),(0,a.jsxs)(`span`,{className:`text-white/30`,children:[` / `,String(n).padStart(2,`0`)]})]})]}),(0,a.jsxs)(`div`,{className:`flex-1 flex flex-col justify-center max-w-6xl mx-auto w-full`,children:[(0,a.jsx)(`div`,{className:`font-display text-5xl sm:text-6xl lg:text-7xl leading-[0.95] tracking-[-0.02em]`,children:l.title}),l.body]}),(0,a.jsxs)(`div`,{className:`flex items-end justify-between gap-6`,children:[(0,a.jsx)(`div`,{className:`font-display font-bold text-base tracking-[0.32em] text-white`,children:`BOREALIS`}),(0,a.jsx)(`div`,{className:`font-mono text-[10px] tracking-[0.22em] uppercase text-white/40`,children:`← → space · 1-9 jump`})]})]}),(0,a.jsx)(`div`,{className:`fixed left-0 right-0 bottom-0 h-[2px] bg-white/8 z-30`,children:(0,a.jsx)(`div`,{className:`h-full bg-cyan-300 transition-[width] duration-500 ease-out`,style:{width:`${(e+1)/n*100}%`}})})]})}function g({pos:e}){return(0,a.jsx)(`span`,{"aria-hidden":!0,className:`fixed z-30 w-7 h-7 border-cyan-300/70 ${{tl:`top-6 left-6 border-l border-t`,tr:`top-6 right-6 border-r border-t`,bl:`bottom-6 left-6 border-l border-b`,br:`bottom-6 right-6 border-r border-b`}[e]}`,style:{filter:`drop-shadow(0 0 6px rgba(94,234,255,0.4))`}})}export{m as Deck};