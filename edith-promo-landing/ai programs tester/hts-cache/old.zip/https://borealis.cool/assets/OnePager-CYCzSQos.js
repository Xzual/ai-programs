import{t as e}from"./jsx-runtime-kJazARoa.js";import{t}from"./copy-DliY2mjT.js";var n=e();function r(){return(0,n.jsxs)(`div`,{className:`bg-neutral-900 min-h-screen flex items-start justify-center py-8 print:bg-white print:py-0`,children:[(0,n.jsxs)(`article`,{className:`one-pager-sheet`,children:[(0,n.jsxs)(`header`,{className:`op-header`,children:[(0,n.jsxs)(`div`,{className:`op-header-brand`,children:[(0,n.jsx)(`img`,{src:`/borealis-sphere.png`,className:`op-logo-sphere`,alt:``}),(0,n.jsx)(`div`,{className:`op-wordmark`,children:`BOREALIS`})]}),(0,n.jsx)(`div`,{className:`op-tagline`,children:`One vendor. One controller. Five times the cooling.`})]}),(0,n.jsx)(`img`,{src:`/borealis-sphere.png`,className:`op-bg-sphere`,alt:``,"aria-hidden":`true`}),(0,n.jsxs)(`section`,{className:`op-strip`,children:[(0,n.jsx)(i,{k:`5×`,v:`Cooling vs. CRAC`}),(0,n.jsx)(i,{k:`14 days`,v:`Site-ready install`}),(0,n.jsx)(i,{k:`$700K/yr`,v:`Energy saved · 2 MW hall`}),(0,n.jsx)(i,{k:`35+ yr`,v:`AGT-USA heritage`})]}),(0,n.jsxs)(`section`,{className:`op-body`,children:[(0,n.jsxs)(`div`,{className:`op-col`,children:[(0,n.jsx)(a,{index:`01`,title:`The Vega system`}),(0,n.jsx)(`p`,{className:`op-intro`,children:`Four components, one controller, one vendor.  Drops into any facility — high-density AI, brownfield retrofit, healthcare, research, manufacturing.  Modular: deploy a single rack, a standalone CDU, or the full turnkey loop.`}),(0,n.jsxs)(`div`,{className:`op-nodes`,children:[(0,n.jsx)(o,{tag:`01`,title:`Rack`,sub:`Rear-door HX`,body:`Cold water takes the heat at the rack door.`}),(0,n.jsx)(o,{tag:`02`,title:`CDU`,sub:`Pumping station`,body:`Twin multistage pumps. Sanitary stainless plumbing.`}),(0,n.jsx)(o,{tag:`03`,title:`Condenser`,sub:`Air-cooled`,body:`Rejects to ambient. One closed thermal path.`}),(0,n.jsx)(o,{tag:`04`,title:`Chiller`,sub:`Refrigerant`,body:`Lifts heat out of the building. One refrigerant loop.`})]}),(0,n.jsx)(a,{index:`02`,title:`Under the hood`}),(0,n.jsxs)(`dl`,{className:`op-dl`,children:[(0,n.jsx)(s,{k:`Pumps`,v:`Vertical multistage, IE5, N+1`}),(0,n.jsx)(s,{k:`Connections`,v:`DN50 tri-clamp, PN25`}),(0,n.jsx)(s,{k:`Plumbing`,v:`Sanitary stainless, sealless dielectric`}),(0,n.jsx)(s,{k:`Module (dual / triple)`,v:`276 / 414 kW`}),(0,n.jsx)(s,{k:`Standard CDU (3 modules)`,v:`829 kW`}),(0,n.jsx)(s,{k:`Max CDU (6 modules)`,v:`1.66 MW`}),(0,n.jsx)(s,{k:`Fleet`,v:`Multi-CDU to 5 MW+`}),(0,n.jsx)(s,{k:`Rating method`,v:`OCP 5 °C · 2.88 LPM/kW`}),(0,n.jsx)(s,{k:`NPSH margin`,v:`≥ 2.0 m`})]}),(0,n.jsx)(a,{index:`03`,title:`Validated`}),(0,n.jsxs)(`dl`,{className:`op-dl`,children:[(0,n.jsx)(s,{k:`Capacity hold`,v:`≥ 95% of rated, all modes`}),(0,n.jsx)(s,{k:`Transient response`,v:`3 to 5 s on load steps`}),(0,n.jsx)(s,{k:`Temperature overshoot`,v:`≤ 0.5 °C`}),(0,n.jsx)(s,{k:`Mechanical Load Coefficient`,v:`≤ 10 W per kW cooled`}),(0,n.jsx)(s,{k:`Acoustics`,v:`≤ 65 dBA @ 1 m`}),(0,n.jsx)(s,{k:`Compliance`,v:`ASHRAE 90.4 · UL 508A · ASME B31.3`}),(0,n.jsx)(s,{k:`Systems shipped`,v:`5,000+ industrial installs`})]})]}),(0,n.jsxs)(`div`,{className:`op-col`,children:[(0,n.jsx)(a,{index:`04`,title:`Three ways in`}),(0,n.jsx)(`p`,{className:`op-intro`,children:`Pick the smallest tier that solves the cooling gap — Borealis modularity lets you start with one rack and scale to a full loop without rip-and-replace.  Every tier is scoped and quoted per site.`}),(0,n.jsxs)(`div`,{className:`op-tiers`,children:[(0,n.jsx)(c,{tier:`Rear-door heat exchanger`,range:`Up to 132 kW`,per:`per rack`,body:`Retrofit a single rack into an existing chilled-water facility.`}),(0,n.jsx)(c,{tier:`Borealis CDU only`,range:`Up to 829 kW`,per:`per unit`,body:`Pumping station alone. Drop into an existing chilled-water loop.`,accent:!0}),(0,n.jsx)(c,{tier:`Complete Vega turnkey`,range:`500 kW`,per:`full system`,body:`RDHX + CDU + condenser + chiller + controls + plumbing. One vendor.`})]}),(0,n.jsx)(a,{index:`05`,title:`Versus a CRAC unit`}),(0,n.jsx)(`table`,{className:`op-compare`,children:(0,n.jsxs)(`tbody`,{children:[(0,n.jsxs)(`tr`,{children:[(0,n.jsx)(`td`,{children:`Vendors`}),(0,n.jsx)(`td`,{className:`op-strike`,children:`4+`}),(0,n.jsx)(`td`,{className:`op-win`,children:`1`})]}),(0,n.jsxs)(`tr`,{children:[(0,n.jsx)(`td`,{children:`Capacity / unit`}),(0,n.jsx)(`td`,{className:`op-strike`,children:`~100 kW`}),(0,n.jsx)(`td`,{className:`op-win`,children:`~500 kW`})]}),(0,n.jsxs)(`tr`,{children:[(0,n.jsx)(`td`,{children:`Install time`}),(0,n.jsx)(`td`,{className:`op-strike`,children:`9 months`}),(0,n.jsx)(`td`,{className:`op-win`,children:`< 2 weeks`})]}),(0,n.jsxs)(`tr`,{children:[(0,n.jsx)(`td`,{children:`Cooling target`}),(0,n.jsx)(`td`,{className:`op-strike`,children:`The room`}),(0,n.jsx)(`td`,{className:`op-win`,children:`The rack`})]}),(0,n.jsxs)(`tr`,{children:[(0,n.jsx)(`td`,{children:`Capacity delta`}),(0,n.jsx)(`td`,{className:`op-strike`,children:`1×`}),(0,n.jsx)(`td`,{className:`op-win`,children:`5× per footprint`})]})]})}),(0,n.jsx)(a,{index:`06`,title:`Contact`}),(0,n.jsx)(`div`,{className:`op-contact`,children:(0,n.jsx)(`div`,{className:`op-contact-line op-contact-line--link op-contact-line--big`,children:`borealis.cool`})})]})]}),(0,n.jsxs)(`footer`,{className:`op-footer`,children:[(0,n.jsx)(`div`,{children:t.copyright}),(0,n.jsx)(`div`,{children:t.trademarks})]})]}),(0,n.jsx)(`style`,{children:`
        /* Letter-sized sheet: 8.5 × 11 in.  At 96 dpi this is
           816 × 1056 px.  We size at 8.5in × 11in directly so
           "Save as PDF" prints at exactly the design size. */
        .one-pager-sheet {
          width: 8.5in;
          min-height: 11in;
          padding: 0.55in 0.6in;
          background: #0a0a0a;
          color: #ffffff;
          font-family: "JetBrains Mono", ui-monospace, "SFMono-Regular", Menlo, monospace;
          font-size: 9px;
          line-height: 1.45;
          letter-spacing: 0.02em;
          box-sizing: border-box;
          position: relative;
          box-shadow: 0 0 0 1px rgba(255,255,255,0.05), 0 20px 60px rgba(0,0,0,0.6);
        }

        /* Header */
        .op-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-bottom: 16px;
          margin-bottom: 18px;
          border-bottom: 1px solid rgba(94, 234, 255, 0.25);
        }
        .op-header-brand { display: flex; align-items: center; gap: 10px; }
        .op-logo-sphere {
          width: 36px;
          height: 36px;
          object-fit: contain;
          flex-shrink: 0;
          /* Match deck's brightness boost so the sphere reads
             the same in header + watermark. */
          filter: brightness(2.5) saturate(2.4) contrast(1.15);
        }
        .op-bg-sphere {
          position: absolute;
          left: 50%;
          top: 50%;
          width: 5in;
          height: 5in;
          transform: translate(-50%, -50%);
          object-fit: contain;
          opacity: 0.22;
          filter: brightness(2.2) saturate(2.2);
          pointer-events: none;
          z-index: 0;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }
        /* All foreground content needs a stacking context above
           the watermark sphere. */
        .op-header, .op-strip, .op-body, .op-footer {
          position: relative;
          z-index: 1;
        }
        .op-wordmark {
          font-family: "PP Neue Machina", "Helvetica Neue", sans-serif;
          font-weight: 700;
          letter-spacing: 0.34em;
          font-size: 15px;
          color: #ffffff;
        }
        .op-tagline {
          font-size: 9px;
          letter-spacing: 0.16em;
          text-transform: uppercase;
          color: rgba(255, 255, 255, 0.6);
        }

        /* Hero stats strip */
        .op-strip {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 12px;
          margin-bottom: 22px;
        }
        .op-stat {
          border: 1px solid rgba(94, 234, 255, 0.25);
          padding: 10px 12px;
          background: rgba(94, 234, 255, 0.04);
        }
        .op-stat-k {
          font-family: "PP Neue Machina", "Helvetica Neue", sans-serif;
          font-weight: 700;
          font-size: 22px;
          line-height: 1;
          color: #5eeaff;
          letter-spacing: -0.02em;
        }
        .op-stat-v {
          margin-top: 6px;
          font-size: 8px;
          letter-spacing: 0.22em;
          text-transform: uppercase;
          color: rgba(255, 255, 255, 0.55);
        }

        /* Body two-column layout */
        .op-body {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 26px;
        }
        .op-col {
          display: flex;
          flex-direction: column;
        }

        /* Section header */
        .op-section-title {
          display: flex;
          align-items: baseline;
          gap: 10px;
          margin-top: 18px;
          margin-bottom: 10px;
          padding-bottom: 5px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .op-section-title:first-of-type { margin-top: 0; }
        .op-section-index {
          font-size: 9px;
          letter-spacing: 0.22em;
          color: #5eeaff;
        }
        .op-section-name {
          font-family: "PP Neue Machina", "Helvetica Neue", sans-serif;
          font-weight: 400;
          font-size: 14px;
          letter-spacing: -0.01em;
          color: #ffffff;
        }
        .op-intro {
          font-size: 9px;
          color: rgba(255, 255, 255, 0.7);
          margin-bottom: 10px;
        }

        /* 4-part system nodes */
        .op-nodes {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 8px;
          margin-bottom: 8px;
        }
        .op-node {
          border: 1px solid rgba(255, 255, 255, 0.1);
          padding: 8px 10px;
        }
        .op-node-tag {
          font-size: 8px;
          letter-spacing: 0.22em;
          color: #5eeaff;
        }
        .op-node-title {
          font-family: "PP Neue Machina", "Helvetica Neue", sans-serif;
          font-weight: 700;
          font-size: 13px;
          color: #ffffff;
          margin-top: 2px;
          letter-spacing: -0.01em;
        }
        .op-node-sub {
          font-size: 8px;
          letter-spacing: 0.16em;
          text-transform: uppercase;
          color: rgba(255, 255, 255, 0.55);
          margin-top: 1px;
        }
        .op-node-body {
          font-size: 9px;
          color: rgba(255, 255, 255, 0.7);
          margin-top: 5px;
          line-height: 1.4;
        }

        /* Definition-list rows */
        .op-dl {
          margin: 0;
        }
        .op-row {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
          gap: 12px;
          padding: 3px 0;
          border-bottom: 1px dotted rgba(255, 255, 255, 0.1);
        }
        .op-row-k {
          font-size: 8px;
          letter-spacing: 0.18em;
          text-transform: uppercase;
          color: rgba(255, 255, 255, 0.55);
          flex-shrink: 0;
        }
        .op-row-v {
          font-size: 9px;
          color: #ffffff;
          text-align: right;
        }

        /* Pricing tier cards */
        .op-tiers {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .op-tier {
          border: 1px solid rgba(255, 255, 255, 0.1);
          padding: 10px 12px;
        }
        .op-tier--accent {
          border-color: rgba(94, 234, 255, 0.5);
          background: rgba(94, 234, 255, 0.04);
        }
        .op-tier-name {
          font-size: 8px;
          letter-spacing: 0.22em;
          text-transform: uppercase;
          color: #5eeaff;
        }
        .op-tier-range {
          font-family: "PP Neue Machina", "Helvetica Neue", sans-serif;
          font-weight: 700;
          font-size: 18px;
          letter-spacing: -0.02em;
          color: #ffffff;
          margin-top: 3px;
        }
        .op-tier-per {
          font-size: 8px;
          letter-spacing: 0.16em;
          text-transform: uppercase;
          color: rgba(255, 255, 255, 0.55);
          margin-top: 1px;
        }
        .op-tier-body {
          font-size: 9px;
          color: rgba(255, 255, 255, 0.7);
          margin-top: 5px;
          line-height: 1.4;
        }

        /* Compare table */
        .op-compare {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 6px;
        }
        .op-compare td {
          font-size: 9px;
          padding: 4px 6px;
          border-bottom: 1px dotted rgba(255, 255, 255, 0.1);
          vertical-align: baseline;
        }
        .op-compare td:first-child {
          font-size: 8px;
          letter-spacing: 0.18em;
          text-transform: uppercase;
          color: rgba(255, 255, 255, 0.55);
          width: 35%;
        }
        .op-strike {
          color: rgba(255, 255, 255, 0.4);
          text-decoration: line-through;
          text-decoration-color: rgba(255, 255, 255, 0.25);
          text-decoration-thickness: 1px;
          width: 30%;
        }
        .op-win {
          color: #ffffff;
          font-weight: 600;
        }

        /* Contact block */
        .op-contact {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }
        .op-contact-line {
          font-size: 9px;
          color: rgba(255, 255, 255, 0.75);
        }
        .op-contact-line--bold {
          color: #ffffff;
          font-weight: 600;
        }
        .op-contact-line--link {
          color: #5eeaff;
        }
        .op-contact-line--big {
          font-family: "PP Neue Machina", "Helvetica Neue", sans-serif;
          font-weight: 700;
          font-size: 16px;
          letter-spacing: 0.02em;
        }

        /* Footer */
        .op-footer {
          margin-top: 20px;
          padding-top: 12px;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
          display: flex;
          justify-content: space-between;
          gap: 18px;
          font-size: 7.5px;
          letter-spacing: 0.18em;
          text-transform: uppercase;
          color: rgba(255, 255, 255, 0.35);
        }

        /* ===== Responsive: scale on narrow phone screens.
                The two-column body stays two-column on tablet and
                up — the previous 1024 px breakpoint was kicking
                in inside headless-Chrome print and breaking the
                PDF layout. ===== */
        @media (max-width: 640px) {
          .one-pager-sheet {
            width: 100%;
            min-height: 0;
            padding: 24px;
            box-shadow: none;
          }
          .op-body { grid-template-columns: 1fr; }
          .op-strip { grid-template-columns: repeat(2, 1fr); }
        }

        /* ===== Print rules — "Save as PDF" outputs the same
                colour scheme + sizing as on-screen.  Force
                color-adjust so the dark background + cyan accents
                actually print, and force the two-column body
                regardless of the print viewport width. ===== */
        @page {
          size: letter;
          margin: 0;
        }
        @media print {
          html, body { background: #ffffff !important; margin: 0; padding: 0; }
          .one-pager-sheet {
            width: 8.5in;
            min-height: 11in;
            padding: 0.45in 0.5in;
            box-shadow: none;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          .op-body { grid-template-columns: 1fr 1fr !important; }
          .op-strip { grid-template-columns: repeat(4, 1fr) !important; }
        }
      `})]})}function i({k:e,v:t}){return(0,n.jsxs)(`div`,{className:`op-stat`,children:[(0,n.jsx)(`div`,{className:`op-stat-k`,children:e}),(0,n.jsx)(`div`,{className:`op-stat-v`,children:t})]})}function a({index:e,title:t}){return(0,n.jsxs)(`div`,{className:`op-section-title`,children:[(0,n.jsx)(`span`,{className:`op-section-index`,children:e}),(0,n.jsx)(`span`,{className:`op-section-name`,children:t})]})}function o({tag:e,title:t,sub:r,body:i}){return(0,n.jsxs)(`div`,{className:`op-node`,children:[(0,n.jsx)(`div`,{className:`op-node-tag`,children:e}),(0,n.jsx)(`div`,{className:`op-node-title`,children:t}),(0,n.jsx)(`div`,{className:`op-node-sub`,children:r}),(0,n.jsx)(`div`,{className:`op-node-body`,children:i})]})}function s({k:e,v:t}){return(0,n.jsxs)(`div`,{className:`op-row`,children:[(0,n.jsx)(`span`,{className:`op-row-k`,children:e}),(0,n.jsx)(`span`,{className:`op-row-v`,children:t})]})}function c({tier:e,range:t,per:r,body:i,accent:a}){return(0,n.jsxs)(`div`,{className:`op-tier ${a?`op-tier--accent`:``}`,children:[(0,n.jsx)(`div`,{className:`op-tier-name`,children:e}),(0,n.jsx)(`div`,{className:`op-tier-range`,children:t}),(0,n.jsx)(`div`,{className:`op-tier-per`,children:r}),(0,n.jsx)(`div`,{className:`op-tier-body`,children:i})]})}export{r as OnePager};