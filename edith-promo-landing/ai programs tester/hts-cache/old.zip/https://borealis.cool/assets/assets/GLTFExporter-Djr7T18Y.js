<!doctype html>
<!--
  ===================================================================
  index.html — Borealis loader + Vite SPA root.

  ╔═════════════════════════════════════════════════════════════════╗
  ║ LOCKED REGION — loader typewriter (search for "rev F.4" /         ║
  ║ "il-phrase-cycle" / "il-type-cover").  The typewriter is        ║
  ║ 100 % CSS — phrase list, animation, cursor, all in the          ║
  ║ <style> block.  There is no JS for the typewriter.  Adding      ║
  ║ JS here re-introduces the freeze-during-mount bug.  See the     ║
  ║ inline banner over the CSS rule before changing anything.       ║
  ╚═════════════════════════════════════════════════════════════════╝
  ===================================================================
-->
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
    <meta name="theme-color" content="#000000" />
    <meta name="color-scheme" content="dark" />
    <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png" />
    <link rel="apple-touch-icon" href="/apple-touch-icon.png" />

    <!-- Google Search Console verification -->
    <meta name="google-site-verification" content="IF1hdkXl_Oti3VkgfyJ3qK7zZsoTUh0cS6V89sTIq54" />
    <!-- Bing Webmaster Tools verification -->
    <meta name="msvalidate.01" content="1E91A4DB4179CCF94849253C0AE7BC49" />

    <!-- Type system (all self-hosted, see index.css @font-face):
         PP Neue Machina  — display (Pangram Pangram, licensed)
         JetBrains Mono   — body + technical specs + overlays -->
    <!-- All fonts are self-hosted; no Google Fonts preconnect needed. -->
    <link
      rel="preload"
      href="/fonts/PPNeueMachina-Ultrabold.otf"
      as="font"
      type="font/otf"
      crossorigin
    />
    <link
      rel="preload"
      href="/fonts/PPNeueMachina-Regular.otf"
      as="font"
      type="font/otf"
      crossorigin
    />
    <link
      rel="preload"
      href="/fonts/PPNeueMachina-Light.otf"
      as="font"
      type="font/otf"
      crossorigin
    />
    <link
      rel="preload"
      href="/fonts/JetBrainsMono-Variable.ttf"
      as="font"
      type="font/ttf"
      crossorigin
    />
    <!-- JetBrainsMono-Italic-Variable.ttf (308 KB) is rare on
         first paint and intentionally NOT preloaded — pulling
         it would cost bandwidth that the marketing landing
         doesn't typically use it for.  It still loads when CSS
         references it; just not on the critical path. -->

    <!-- Preload the two heavy GLBs the MeetVega CDU assembly
         depends on (rooftop HVAC + server-rack rear-door).
         Both are ~13–16 MB and would otherwise wait for the
         lazy CDU chunk to arrive before the network fetch even
         starts.  By preloading at HTML-parse time we run the
         download in parallel with everything else the loader is
         already waiting for (React, fonts, lazy chunks), so the
         GLBs are ready by the time AssemblyReadyBeacon mounts. -->
    <link rel="preload" href="/server-rack.glb" as="fetch" crossorigin />
    <link rel="preload" href="/trane-yc40.glb"  as="fetch" crossorigin />

    <title>Borealis: Turnkey AI Data Centers</title>
    <meta
      name="description"
      content="AI data centers, delivered turnkey. Borealis HALO puts 2 MW on wheels, pad to power in 15 days. Proven liquid cooling, NVIDIA compute, one vendor."
    />

    <!-- Open Graph (Facebook / LinkedIn / Discord / Slack previews). -->
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="Borealis" />
    <meta property="og:url" content="https://borealis.cool/" />
    <meta property="og:title" content="Borealis: Turnkey AI Data Centers" />
    <meta property="og:description" content="AI data centers, delivered turnkey. Borealis HALO puts 2 MW on wheels, pad to power in 15 days. Proven liquid cooling, NVIDIA compute, one vendor." />
    <meta property="og:image" content="https://borealis.cool/og-image.png?v=3" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta property="og:image:type" content="image/png" />
    <meta property="og:image:alt" content="The Borealis wordmark over black with the tagline Turnkey AI Data Centers." />

    <!-- Twitter / X — large summary card so the OG image gets full width. -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="Borealis: Turnkey AI Data Centers" />
    <meta name="twitter:description" content="AI data centers, delivered turnkey. Borealis HALO puts 2 MW on wheels, pad to power in 15 days. Proven liquid cooling, NVIDIA compute, one vendor." />
    <meta name="twitter:image" content="https://borealis.cool/og-image.png?v=3" />
    <meta name="twitter:image:alt" content="The Borealis wordmark over black with the tagline Turnkey AI Data Centers." />

    <!-- Structured data for AI assistants + search engines. The site itself is a
         WebGL SPA whose content is JS-rendered, so this JSON-LD is the machine-
         readable source of truth that crawlers can read without executing JS. -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "Organization",
          "@id": "https://borealis.cool/#org",
          "name": "Borealis",
          "legalName": "AGT-USA Inc.",
          "url": "https://borealis.cool/",
          "logo": "https://borealis.cool/borealis-wordmark-bold.png",
          "description": "Borealis, by AGT-USA, delivers turnkey liquid-cooled AI data centers: best-in-class liquid cooling paired with NVIDIA compute, from one vendor. Water-free, rated to 50 C ambient, built for NVIDIA GB200 and GB300 NVL72 density.",
          "foundingLocation": "Corona, California, USA",
          "address": { "@type": "PostalAddress", "streetAddress": "235 Jason Court", "addressLocality": "Corona", "addressRegion": "CA", "postalCode": "92882", "addressCountry": "US" },
          "areaServed": "Worldwide",
          "knowsAbout": ["liquid cooling", "AI data centers", "data center cooling", "mobile AI data centers", "NVIDIA GB300 NVL72", "rear-door heat exchanger", "coolant distribution unit", "direct-to-chip cooling", "high-density compute"]
        },
        {
          "@type": "Product",
          "name": "Borealis HALO",
          "brand": { "@id": "https://borealis.cool/#org" },
          "category": "Turnkey mobile AI data center",
          "url": "https://borealis.cool/products",
          "description": "A complete 2 MW AI data center that arrives on wheels: compute, cooling, power, and controls factory-integrated across three to four road-legal modules. The enclosure is the heat exchanger: coil-bank walls and a roof fan array reject the full load dry, with zero process water in any mode. Pad to power in 10 to 15 working days, 14 NVL72-class racks and 1,008 GPUs day one, scaling in 2 MW blocks to 20 MW and beyond. Fully reversible: no permanent structure."
        },
        {
          "@type": "Product",
          "name": "Vega AIO",
          "brand": { "@id": "https://borealis.cool/#org" },
          "category": "Self-contained liquid-cooled AI data center",
          "url": "https://borealis.cool/vega",
          "description": "A self-contained AI data center in one in-line unit: three rack bays built for NVIDIA-class compute, rear-door heat exchangers, a CDU, and an onboard chiller, carrying 500 kW, about 5x the cooling density of a CRAC in the same footprint. Runs in as little as a week on site."
        },
        {
          "@type": "Product",
          "name": "Borealis Retrofit",
          "brand": { "@id": "https://borealis.cool/#org" },
          "category": "Liquid cooling retrofit for existing data halls",
          "description": "The complete Borealis cooling plant delivered inside a building you already own and power, in modular wings. Each wing carries 829 kW of cooling for six NVL72-class racks, about 8x a CRAC, scaling up to 96 racks, 12.7 MW, and 6,912 GPUs per hall. First wing live in 14 days, a full hall in 8 to 10 weeks."
        },
        {
          "@type": "FAQPage",
          "mainEntity": [
            { "@type": "Question", "name": "What is Borealis?", "acceptedAnswer": { "@type": "Answer", "text": "Borealis, by AGT-USA, delivers turnkey liquid-cooled AI data centers, pairing best-in-class liquid cooling with NVIDIA compute from a single vendor. Its products are the Borealis HALO, a complete 2 MW AI data center that arrives on wheels; the Vega AIO, a self-contained data center in one unit; and Borealis Retrofit, the complete cooling plant delivered inside your existing hall." } },
            { "@type": "Question", "name": "How does Borealis cool high-density AI racks?", "acceptedAnswer": { "@type": "Answer", "text": "Borealis cools at the rack with a closed liquid loop instead of cooling the room with air. Direct-to-chip cold plates and rear-door heat exchangers pull heat off the servers, a CDU pumps the isolated loop, a chiller makes the cold, and a rooftop air-cooled condenser rejects heat to outside air. The system is water-free and rated to 50 C ambient." } },
            { "@type": "Question", "name": "How fast can a Borealis AI data center be deployed?", "acceptedAnswer": { "@type": "Answer", "text": "The Borealis HALO goes from a prepared pad to first power in 10 to 15 working days. The self-contained Vega AIO runs in as little as a week on site. For Borealis Retrofit, the first wing is live in 14 days and a full 96-rack hall in 8 to 10 weeks, versus roughly 270 days for a conventional multi-vendor build." } },
            { "@type": "Question", "name": "Does Borealis cooling work in hot climates like the Middle East?", "acceptedAnswer": { "@type": "Answer", "text": "Yes. The cooling is air-cooled at heat rejection and consumes no water, and it is rated to 50 C ambient, which suits hot, water-scarce regions including the Gulf." } }
          ]
        }
      ]
    }
    </script>

    <!-- Initial loader — paints inline from byte 1, before
         React + fonts + main bundle. Everything is driven by a
         single integer `pct` set from a rAF loop: the bar
         widths, the number, and the rotating status phrase all
         read from the same value every frame, so they can never
         drift out of sync. The minimum on-screen floor + the
         ready-signal handoff stay the same as before; only the
         drive train changed. -->
    <style>
      #initial-loader {
        position: fixed;
        inset: 0;
        z-index: 9999;
        background: #000;
        color: #fff;
        font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: opacity 0.55s ease;
      }
      #initial-loader.is-gone {
        opacity: 0;
        pointer-events: none;
      }

      /* === HUD corner brackets === */
      #initial-loader .il-corner {
        position: absolute;
        width: 26px;
        height: 26px;
        border: 1.4px solid rgba(94, 234, 255, 0.95);
        /* drop-shadow (not box-shadow) — follows the L-shape
           of the actual borders instead of painting a square
           halo over the corner, which made the previous
           brackets read as "overlapping squares". */
        filter: drop-shadow(0 0 6px rgba(94, 234, 255, 0.45));
      }
      #initial-loader .il-corner--tl {
        top: max(22px, env(safe-area-inset-top, 22px));
        left: 22px;
        border-right: 0;
        border-bottom: 0;
      }
      #initial-loader .il-corner--tr {
        top: max(22px, env(safe-area-inset-top, 22px));
        right: 22px;
        border-left: 0;
        border-bottom: 0;
      }
      #initial-loader .il-corner--bl {
        bottom: max(22px, env(safe-area-inset-bottom, 22px));
        left: 22px;
        border-right: 0;
        border-top: 0;
      }
      #initial-loader .il-corner--br {
        bottom: max(22px, env(safe-area-inset-bottom, 22px));
        right: 22px;
        border-left: 0;
        border-top: 0;
      }

      /* === Centred stack: logo / wordmark / meter / status === */
      #initial-loader .il-stage {
        position: relative;
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 0 22px;
      }
      #initial-loader .il-logo-wrap {
        position: relative;
        width: 64px;
        height: 64px;
        filter: drop-shadow(0 0 18px rgba(94, 234, 255, 0.45));
      }
      #initial-loader .il-logo {
        display: block;
        width: 100%;
        height: 100%;
      }
      /* Static logo dot — same cyan gradient as before, just
         no longer pulsing.  The favicon's centre is supposed
         to read as an "alive" indicator without needing a
         distracting heartbeat animation. */
      #initial-loader .il-logo-dot {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 9px;
        height: 9px;
        border-radius: 50%;
        background: linear-gradient(135deg, #5eeaff 0%, #7da8ff 100%);
        transform: translate(-50%, -50%);
        pointer-events: none;
      }
      #initial-loader .il-wordmark {
        margin-top: 0.95rem;
        font-family: "PP Neue Machina", ui-sans-serif, system-ui, sans-serif;
        font-weight: 700;
        font-size: 0.78rem;
        letter-spacing: 0.42em;
        color: #fff;
      }

      /* === Meter row: [line ====] 67 [line ====] === */
      #initial-loader .il-meter {
        margin-top: 1.8rem;
        display: flex;
        align-items: center;
        gap: 0.85rem;
        width: min(420px, 86vw);
      }
      /* Bars are sized via inline transform written by the JS
         rAF loop every frame.  Starts at scaleX(0.02) so a
         thin glow is visible from the first paint.  Glow tuned
         tight (4 px) so the bar's halo never reaches the
         typewriter row below — the previous 8 px glow could
         visually crowd the typer when the bars were near-full
         length around 70-90 %. */
      #initial-loader .il-line {
        flex: 1;
        height: 1px;
        background: linear-gradient(
          90deg,
          rgba(94, 234, 255, 0) 0%,
          rgba(94, 234, 255, 0.85) 100%
        );
        box-shadow: 0 0 4px rgba(94, 234, 255, 0.30);
        transform-origin: 0% 50%;
        transform: scaleX(0.02);
        will-change: transform;
      }
      #initial-loader .il-line--r {
        transform-origin: 100% 50%;
        background: linear-gradient(
          90deg,
          rgba(94, 234, 255, 0.85) 0%,
          rgba(94, 234, 255, 0) 100%
        );
      }
      #initial-loader .il-percent-wrap {
        display: inline-flex;
        align-items: baseline;
        gap: 0.18rem;
        min-width: 4ch;
        justify-content: center;
        filter: drop-shadow(0 0 12px rgba(94, 234, 255, 0.35));
      }
      #initial-loader .il-percent {
        font-family: "PP Neue Machina", ui-sans-serif, system-ui, sans-serif;
        font-weight: 300;   /* was 700 — un-bolded so the number reads light + spacious */
        font-size: 1.85rem;
        line-height: 1;
        letter-spacing: -0.01em;
        color: #fff;
        font-variant-numeric: tabular-nums;
        display: inline-block;
        text-align: center;
        min-width: 3ch;
      }
      #initial-loader .il-percent-sym {
        font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        font-size: 0.7rem;
        letter-spacing: 0.1em;
        color: rgba(94, 234, 255, 0.7);
      }
      /* Status phrase — compositor-only typewriter.

         The text row sits inside a fixed-width inline-block
         wrapper that's centred in .il-status.  A black cover
         element overlays the whole row with transform-origin
         pinned at 100% (the right edge), and runs a CSS keyframe
         scaling 1 → 0 → 0 → 1.  As scaleX shrinks toward 0, the
         cover collapses RIGHTWARD (toward its origin), revealing
         the text left-to-right — a clean typewriter reveal that
         runs entirely on the compositor thread.  Heavy main-
         thread work (GLB parses) cannot freeze this motion.  JS
         does exactly one thing: swap the underlying text on each
         animationiteration event, which lands while the cover is
         back at scaleX(1) and the text is invisible — so the swap
         itself is never visible.

         Because the text content is always the full phrase in the
         DOM, the wrapper's width never changes mid-cycle — the
         visible typewriter has no "expanding from the centre"
         re-centring artefact.

         Font / size / colour / tracking on .il-status, plus the
         cursor's 7px × 0.85em / 65 % white / 0.85s blink, all
         match the hero scroll-prompt typewriter above the bobbing
         arrow. */
      #initial-loader .il-status {
        /* Bumped from 1.1rem → 2.4rem so the typewriter has
           clear breathing room from the meter / bar glow.  When
           the bars approach full length (70-90 % loaded), the
           old 1.1rem gap let the bar's halo + percent text feel
           visually crowded against the typer row. */
        margin-top: 2.4rem;
        /* Match the hero scroll-prompt typewriter exactly:
             font-mono           → JetBrains Mono variable
             text-[11px]         → 11 px
             tracking-[0.26em]   → letter-spacing 0.26em
             text-white/60       → rgba(255,255,255,0.6) */
        font-family: "JetBrains Mono", ui-monospace, "SFMono-Regular", Menlo, monospace;
        font-size: 11px;
        letter-spacing: 0.26em;
        text-transform: uppercase;
        color: rgba(255, 255, 255, 0.6);
        height: 1em;
        line-height: 1;
        text-align: center;
        white-space: nowrap;
      }
      /* ╔══════════════════════════════════════════════════════════╗
         ║  LOADER TYPEWRITER — REBUILD (rev F.4.4)                   ║
         ║                                                          ║
         ║  4 phrases, opacity-cycled in a single inline-grid wrap. ║
         ║  Each phrase has its OWN cover + cursor.  Every animated ║
         ║  property is compositor-only (transform + opacity) and   ║
         ║  force-promoted to the GPU layer via translate3d /       ║
         ║  scale3d + will-change + backface-visibility: hidden:    ║
         ║                                                          ║
         ║    1. .il-typer-phr   opacity 0/1 (20 s loop, 5 s slot)  ║
         ║    2. .il-typer-cover scale3d(1→0→0→1→1) (5 s)           ║
         ║    3. .il-typer-cursor translate3d(0→100cqw→0) (5 s)     ║
         ║    4. .il-typer-cursor opacity blink (0.85 s)            ║
         ║                                                          ║
         ║  Phrases are plain DOM <span class="il-typer-text">.  No ║
         ║  @keyframes content animation, no JS, no class swaps.    ║
         ║  Anything that needs layout or main-thread work has been ║
         ║  deleted.                                                ║
         ║                                                          ║
         ║  To change a phrase, edit the <span class="il-typer-     ║
         ║  text"> string inside the matching <div class="il-phr-N">║
         ║  in the <body> below.  To change phrase count, edit BOTH ║
         ║  the markup AND the il-phr-show keyframe + per-phrase    ║
         ║  animation-delay rules (delays go 0s, T/N, 2T/N, …).     ║
         ╚══════════════════════════════════════════════════════════╝ */
      #initial-loader .il-typer-wrap {
        /* The wrap is now just a stacking-context container —
           it has no intrinsic width.  Each .il-typer-phr child
           is its OWN absolutely-positioned, content-sized wrap
           centred on the row.  This means there's no "widest
           phrase" sizing — every phrase is centred around its
           own text width.  No shift animation needed; the typed
           text is naturally centred at every moment because the
           per-phrase wrap is centred. */
        position: relative;
        display: block;
        height: 1em;
        line-height: 1;
        max-width: 90vw;
        margin: 0 auto;
        text-align: center;
      }
      #initial-loader .il-typer-phr {
        /* Each phrase is its own self-contained typewriter,
           absolutely positioned at the row centre.  Sized to its
           own text via white-space: nowrap.  Two animations:

             1. il-phr-show — opacity 1 for the phrase's 5 s slot
                of the 20 s loop, 0 otherwise.

             2. il-phr-shift — transform: translate3d(0 → -50%
                → 0) synced with the cover.  At cover scale=1
                (fully covered), phrase left edge sits at viewport
                centre (translate3d(0)).  At cover scale=0 (fully
                typed), phrase centred via translate3d(-50%).  The
                visible (uncovered) portion of the text therefore
                stays centred on viewport at every moment of the
                type-in — text appears to grow OUTWARD from
                viewport centre, matching the home-page hero.

           Both transforms use translate3d to keep the phrase on
           its own GPU compositor layer (will-change + backface
           reinforce).  Animation-fill-mode is intentionally
           omitted — base values handle the delay window. */
        position: absolute;
        top: 0;
        left: 50%;
        height: 1em;
        line-height: 1;
        white-space: nowrap;
        opacity: 0;
        will-change: opacity, transform;
        backface-visibility: hidden;
        -webkit-backface-visibility: hidden;
        animation:
          il-phr-show 20s linear infinite,
          il-phr-shift 5s steps(50, end) infinite;
      }
      @keyframes il-phr-show {
        0%      { opacity: 1; }
        25%     { opacity: 1; }
        25.001% { opacity: 0; }
        100%    { opacity: 0; }
      }
      @keyframes il-phr-shift {
        /* Absolute transform values (not deltas from a base
           transform).  Keyframe percentages match the cover's
           0 / 28 / 80 / 94 / 100 timeline so phrase + cover stay
           in lockstep. */
        0%   { transform: translate3d(0,    0, 0); }   /* cover s=1, fully covered */
        28%  { transform: translate3d(-50%, 0, 0); }   /* cover s=0, fully typed (centred) */
        80%  { transform: translate3d(-50%, 0, 0); }   /* hold */
        94%  { transform: translate3d(0,    0, 0); }   /* cover s=1, fully erased */
        100% { transform: translate3d(0,    0, 0); }
      }
      /* animation-delay is comma-separated: (show, shift).  Show
         is offset by 5 s × index.  Shift has 0 delay for all —
         its 5 s cycle naturally aligns with each phrase's 5 s
         visible slot. */
      #initial-loader .il-phr-1 { animation-delay:  0s, 0s; }
      #initial-loader .il-phr-2 { animation-delay:  5s, 0s; }
      #initial-loader .il-phr-3 { animation-delay: 10s, 0s; }
      #initial-loader .il-phr-4 { animation-delay: 15s, 0s; }
      #initial-loader .il-typer-text {
        display: inline-block;
      }
      #initial-loader .il-typer-track {
        /* Sized to the wrap via inset: 0.  container-type: inline-
           size establishes a container-query context so 100cqw
           inside resolves to the wrap\'s text width — used by the
           cursor to land exactly at the phrase\'s right edge with
           no JS measurement. */
        position: absolute;
        inset: 0;
        container-type: inline-size;
        display: block;
      }
      #initial-loader .il-typer-cover {
        position: absolute;
        inset: 0;
        background: #000;
        transform: scale3d(1, 1, 1);
        transform-origin: 100% 50%;
        will-change: transform;
        backface-visibility: hidden;
        -webkit-backface-visibility: hidden;
        animation: il-type-cover 5s steps(50, end) infinite;
      }
      @keyframes il-type-cover {
        0%   { transform: scale3d(1, 1, 1); }
        28%  { transform: scale3d(0, 1, 1); }
        80%  { transform: scale3d(0, 1, 1); }
        94%  { transform: scale3d(1, 1, 1); }
        100% { transform: scale3d(1, 1, 1); }
      }
      #initial-loader .il-typer-cursor {
        position: absolute;
        left: 0;
        bottom: 0;
        width: 7px;
        height: 0.85em;
        background: rgba(255, 255, 255, 0.65);
        will-change: transform, opacity;
        backface-visibility: hidden;
        -webkit-backface-visibility: hidden;
        animation:
          il-cursor-blink 0.85s linear infinite,
          il-cursor-pos 5s steps(50, end) infinite;
      }
      @keyframes il-cursor-blink {
        0%, 49% { opacity: 1; }
        50%, 100% { opacity: 0; }
      }
      @keyframes il-cursor-pos {
        0%   { transform: translate3d(0, 0, 0); }
        28%  { transform: translate3d(100cqw, 0, 0); }
        80%  { transform: translate3d(100cqw, 0, 0); }
        94%  { transform: translate3d(0, 0, 0); }
        100% { transform: translate3d(0, 0, 0); }
      }

      @media (prefers-reduced-motion: reduce) {
        #initial-loader .il-line { transition: none; }
      }
    </style>
    <script type="module" crossorigin src="/assets/index-CXsn75Rf.js"></script>
    <link rel="modulepreload" crossorigin href="/assets/chunk-BNv3lrIs.js">
    <link rel="modulepreload" crossorigin href="/assets/preload-helper-ca-nBW7U.js">
    <link rel="modulepreload" crossorigin href="/assets/jsx-runtime-kJazARoa.js">
    <link rel="modulepreload" crossorigin href="/assets/react-BFwN_vxz.js">
    <link rel="modulepreload" crossorigin href="/assets/scheduler-CYsWOjxp.js">
    <link rel="stylesheet" crossorigin href="/assets/index-B7iaG9PV.css">
  </head>
  <body class="bg-black text-white antialiased">
    <div id="initial-loader" aria-hidden="true">
      <span class="il-corner il-corner--tl"></span>
      <span class="il-corner il-corner--tr"></span>
      <span class="il-corner il-corner--bl"></span>
      <span class="il-corner il-corner--br"></span>

      <div class="il-stage">
        <div class="il-logo-wrap">
          <svg class="il-logo" viewBox="0 0 32 32" aria-hidden="true">
            <defs>
              <linearGradient id="il-g" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stop-color="#5eeaff"/>
                <stop offset="1" stop-color="#7da8ff"/>
              </linearGradient>
            </defs>
            <circle cx="16" cy="16" r="11" stroke="url(#il-g)" stroke-width="1" fill="none" opacity="0.55"/>
            <path d="M16 5 a11 11 0 0 1 0 22" stroke="url(#il-g)" stroke-width="1.8" fill="none" stroke-linecap="round"/>
          </svg>
          <span class="il-logo-dot" aria-hidden="true"></span>
        </div>

        <div class="il-wordmark">BOREALIS</div>

        <div class="il-meter">
          <span class="il-line il-line--l" id="il-line-l" aria-hidden="true"></span>
          <span class="il-percent-wrap">
            <span class="il-percent" id="il-percent">0</span>
            <span class="il-percent-sym">%</span>
          </span>
          <span class="il-line il-line--r" id="il-line-r" aria-hidden="true"></span>
        </div>

        <div class="il-status">
          <div class="il-typer-wrap" aria-hidden="true">
            <div class="il-typer-phr il-phr-1">
              <span class="il-typer-text">Booting up cooling system</span>
              <span class="il-typer-track">
                <span class="il-typer-cover"></span>
                <span class="il-typer-cursor"></span>
              </span>
            </div>
            <div class="il-typer-phr il-phr-2">
              <span class="il-typer-text">Calibrating thermal sensors</span>
              <span class="il-typer-track">
                <span class="il-typer-cover"></span>
                <span class="il-typer-cursor"></span>
              </span>
            </div>
            <div class="il-typer-phr il-phr-3">
              <span class="il-typer-text">Balancing coolant loops</span>
              <span class="il-typer-track">
                <span class="il-typer-cover"></span>
                <span class="il-typer-cursor"></span>
              </span>
            </div>
            <div class="il-typer-phr il-phr-4">
              <span class="il-typer-text">Sequencing pump arrays</span>
              <span class="il-typer-track">
                <span class="il-typer-cover"></span>
                <span class="il-typer-cursor"></span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- The loader's `pct` is driven each frame by the MAXIMUM
         of two sources, so the bar always reflects what's
         actually happening in the background:

           1. Event milestones.
              main.tsx calls window.__borealisLoaderEvent(name)
              as React mounts, fonts decode, the Stage canvas
              mounts, the heavy GLBs finish parsing, and the
              full assembly paints its first frame.  Each event
              sets a milestone level on a fixed schedule
              (react=22, fonts=38, stage=55, glbs=78, assembly
              =95) and the bar's target ratchets up to the
              highest milestone hit.

           2. Time-based drift.
              An ease-out curve crawls 0 → 88 over a "typical
              load time" budget (10s mobile / 6s desktop).
              This guarantees the bar is always moving even
              when no milestone has fired — no flat pauses.

         The visible pct chases the larger of the two each
         frame via a 10% ease, so jumps from milestone events
         look smooth.  When `assembly` fires, a 600ms overlap
         window starts: the bar continues its ease toward 95,
         then snaps to 100 and fades.  The overlap is what the
         user asked for — "everything has finished downloading
         for a beat, then the loader closes." -->
    <script>
      (function () {
        var el = document.getElementById('initial-loader');
        var lineL = document.getElementById('il-line-l');
        var lineR = document.getElementById('il-line-r');
        var percentEl = document.getElementById('il-percent');
        if (!el || !lineL || !lineR || !percentEl) return;

        /* Skip the loader entirely on routes that don't need the
           heavy 3D MeetVega assembly to be ready: the in-depth
           Vega page (/vega), the slide deck (/deck), and the
           one-pager (/onepager).  None of those mount the
           BorealisCduAssembly, so the loader would just block
           the user from seeing the page for no reason.  Remove
           the loader DOM immediately so it doesn't paint at all,
           then short-circuit the rest of this script.  Same path-
           detection that main.tsx uses to route. */
        var pathname = (window.location.pathname || '/').replace(/\/+$/, '')
        if (pathname === '' || pathname === '/vega' || pathname === '/deck' || pathname === '/onepager' || pathname === '/sphere-snapshot' || pathname === '/v2' || pathname === '/v2-room' || pathname === '/v2-cdu' || pathname === '/v2-cdu-lab' || pathname === '/v2-ecosystem' || pathname === '/v2-vega') {
          if (el.parentNode) el.parentNode.removeChild(el)
          /* Stub the public API so main.tsx's later milestone
             calls don't crash. */
          window.__borealisLoaderEvent = function () {}
          window.__borealisHideLoader = function () {}
          return
        }

        var startedAt = performance.now();
        var isMobile = window.innerWidth < 768;
        /* Drift configuration — the time-based filler that
           keeps the bar moving when no milestone is firing.
           Tuned so the drift alone reaches near-ceiling at
           the *typical* load time for each viewport class;
           any actual milestone events will be ahead of drift
           on fast networks and pull the bar up faster. */
        var driftDurationMs = isMobile ? 10000 : 6500;
        var driftCeiling = 88;

        /* Event-milestone schedule — fired by main.tsx via the
           __borealisLoaderEvent() API exposed below. Picked so
           the spacing roughly matches the order in which they
           land during a real cold-load. */
        var MILESTONES = {
          react: 22,
          fonts: 38,
          stage: 55,
          glbs:  78,
          assembly: 95,
        };

        /* Snap-to-100 overlap window — how long after the
           "assembly" event we keep showing the loader before
           jumping the target to 100.  Gives the visible bar a
           ~1s tail past actual readiness, which feels less
           abrupt than a hard cut. */
        var snapOverlapMs = 600;

        var pct = 0;                 /* visible value, monotonic */
        var milestonePct = 0;        /* highest milestone hit so far */
        var snapAt = -1;             /* when to start the 100% snap */
        var done = false;

        /* ╔══════════════════════════════════════════════════════╗
           ║  TYPEWRITER IS 100 % CSS — NO JS HERE (rev F.4).       ║
           ║  Phrase list, type/erase animation, and cursor are   ║
           ║  all in the <style> block (search "rev F.4" or         ║
           ║  "il-phrase-cycle").  Adding JS here re-introduces   ║
           ║  the freeze-during-mount bug.  Do not put a phrases  ║
           ║  array or an animationiteration listener back in.    ║
           ╚══════════════════════════════════════════════════════╝ */

        function render(p) {
          var clamped = p < 0 ? 0 : p > 100 ? 100 : p;
          var s = (clamped / 100).toFixed(4);
          lineL.style.transform = 'scaleX(' + s + ')';
          lineR.style.transform = 'scaleX(' + s + ')';
          percentEl.textContent = String(Math.floor(clamped));
          /* Status text is owned by the typewriter — render()
             does NOT touch it.  The typewriter is 100 % CSS
             (rev F.4): no phrase array, no class swap, no
             textContent assignment, ever.  See <style>. */
        }
        render(0);

        function easeOutCubic(t) { return 1 - Math.pow(1 - t, 3); }

        function tick(now) {
          if (done) return;

          /* 1. Drift contribution. */
          var elapsed = now - startedAt;
          var driftT = elapsed > driftDurationMs ? 1 : elapsed / driftDurationMs;
          var drift = easeOutCubic(driftT) * driftCeiling;

          /* 2. Target = highest of drift OR milestone OR 100
                if the snap window has elapsed. */
          var target;
          if (snapAt > 0 && now >= snapAt) {
            target = 100;
          } else {
            target = drift > milestonePct ? drift : milestonePct;
          }

          /* 3. Ease the visible pct toward the target.  Faster
                chase factor near the end so the final 99 → 100
                doesn't appear to crawl. */
          var chase = target >= 99 ? 0.18 : 0.10;
          var next = pct + (target - pct) * chase;
          /* Snap fully once we're within 0.3 of the target — kills
             the long asymptotic tail of exponential ease. */
          if (target === 100 && next >= 99.7) next = 100;
          if (next > pct) pct = next;
          render(pct);

          if (pct >= 100) {
            /* Done — JS only fades out the loader.  It does NOT
               touch the typewriter (no class swap that the
               typewriter CSS reads).  The typewriter keeps
               cycling phrases right up until the whole loader
               is removed from the DOM.  A 'borealis:loader-gone'
               event is also fired here in case any later
               component wants to lazily start work after the
               loader is fully gone — currently nothing listens
               for it (MeetVega mounts its Canvas during the
               loader so the CDU is ready when the page lands). */
            done = true;
            window.setTimeout(function () {
              el.classList.add('is-gone');
              window.setTimeout(function () {
                if (el.parentNode) el.parentNode.removeChild(el);
                window.dispatchEvent(new Event('borealis:loader-gone'));
              }, 800);
            }, 300);
            return;
          }
          /* Typewriter is compositor-driven via CSS keyframes,
             so the rAF tick doesn't drive it any more — the
             cover element's animationiteration listener handles
             phrase swaps. */
          window.requestAnimationFrame(tick);
        }
        window.requestAnimationFrame(tick);

        /* PUBLIC API ===========================================
           main.tsx calls these as each phase of the boot lands.
           __borealisLoaderEvent(name) bumps the milestone target.
           __borealisHideLoader() is kept for back-compat and
           treated as a shortcut for the 'assembly' event. */
        window.__borealisLoaderEvent = function (name) {
          var v = MILESTONES[name];
          if (typeof v !== 'number') return;
          if (v > milestonePct) milestonePct = v;
          if (name === 'assembly' && snapAt < 0) {
            snapAt = performance.now() + snapOverlapMs;
          }
        };
        window.__borealisHideLoader = function () {
          window.__borealisLoaderEvent('assembly');
        };
      })();
    </script>

    <div id="root"></div>
  </body>
</html>
